package com.example.api.model;

import javax.persistence.*;

@Entity
@Table(name = "commodity")
public class Product {

    @Id
    private String id;

    private Integer count;

    private String name;

    // 只保留这三个字段，完全移除其他字段
    public Product() {}

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public Integer getCount() { return count; }
    public void setCount(Integer count) { this.count = count; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
}