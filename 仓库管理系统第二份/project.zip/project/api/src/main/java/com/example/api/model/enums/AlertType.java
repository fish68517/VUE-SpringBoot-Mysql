package com.example.api.model.enums;

public enum AlertType {
    LOW_STOCK,      // 低库存预警
    OVER_STOCK     // 高库存预警
}
