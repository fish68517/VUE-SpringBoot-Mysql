package com.example.api.service;

public interface UserService {
}
