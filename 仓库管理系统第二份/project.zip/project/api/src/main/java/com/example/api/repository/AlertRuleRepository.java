package com.example.api.repository;

import com.example.api.model.AlertRule;
import com.example.api.model.enums.AlertType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AlertRuleRepository extends JpaRepository<AlertRule, Long> {

    /**
     * 查找所有启用的预警规则
     */
    List<AlertRule> findByIsActiveTrue();

    /**
     * 根据商品ID查找预警规则 - 改为String
     */
    List<AlertRule> findByProductId(String productId);

    /**
     * 根据商品ID查找启用的预警规则 - 改为String
     */
    List<AlertRule> findByProductIdAndIsActiveTrue(String productId);

    /**
     * 根据商品ID和规则类型查找 - 改为String
     */
    AlertRule findByProductIdAndRuleTypeAndIsActiveTrue(String productId, AlertType ruleType);

    /**
     * 检查是否存在指定商品的预警规则 - 新增方法
     */
    boolean existsByProductId(String productId);

    /**
     * 根据商品ID列表查找预警规则 - 新增方法
     */
    List<AlertRule> findByProductIdIn(List<String> productIds);

    /**
     * 根据规则类型查找预警规则 - 新增方法
     */
    List<AlertRule> findByRuleType(AlertType ruleType);

    /**
     * 根据规则类型和启用状态查找 - 新增方法
     */
    List<AlertRule> findByRuleTypeAndIsActiveTrue(AlertType ruleType);

    /**
     * 自定义查询：查找库存低于指定值的低库存预警规则
     */
    @Query("SELECT ar FROM AlertRule ar WHERE ar.ruleType = 'LOW_STOCK' AND ar.minStock < :threshold AND ar.isActive = true")
    List<AlertRule> findLowStockRulesWithThreshold(@Param("threshold") Integer threshold);

    /**
     * 自定义查询：查找库存高于指定值的高库存预警规则
     */
    @Query("SELECT ar FROM AlertRule ar WHERE ar.ruleType = 'OVER_STOCK' AND ar.maxStock > :threshold AND ar.isActive = true")
    List<AlertRule> findOverStockRulesWithThreshold(@Param("threshold") Integer threshold);

    /**
     * 统计每个商品的预警规则数量
     */
    @Query("SELECT ar.productId, COUNT(ar) FROM AlertRule ar GROUP BY ar.productId")
    List<Object[]> countRulesByProduct();

    /**
     * 根据商品ID删除所有预警规则
     */
    void deleteByProductId(String productId);

    /**
     * 根据商品ID列表删除预警规则
     */
    void deleteByProductIdIn(List<String> productIds);
}