package com.example.api.repository;

import com.example.api.model.Commodity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CommodityRepository extends JpaRepository<Commodity, String> {

    // 根据名称模糊搜索 - 使用Containing更符合Spring Data JPA规范
    List<Commodity> findByNameContaining(String name);

    // 或者使用Like，但需要手动添加%
    @Query("SELECT c FROM Commodity c WHERE c.name LIKE %:name%")
    List<Commodity> findAllByNameLike(@Param("name") String name);

    // 根据库存范围查找商品
    List<Commodity> findByCountBetween(Integer minCount, Integer maxCount);

    // 根据价格范围查找商品
    List<Commodity> findByPriceBetween(Double minPrice, Double maxPrice);

    // 查找库存低于指定值的商品（用于预警）
    List<Commodity> findByCountLessThan(Integer count);

    // 查找库存高于指定值的商品（用于预警）- 移除重复的定义
    // List<Commodity> findByCountGreaterThan(Integer count); // 这个重复了，移除

    // 根据名称精确查找
    Optional<Commodity> findByName(String name);

    // 查找有库存的商品（使用大于0）
    List<Commodity> findByCountGreaterThan(Integer count);

    // 查找无库存的商品
    List<Commodity> findByCountEquals(Integer count);

    // 复杂查询：查找名称包含关键词且价格在指定范围内的商品
    @Query("SELECT c FROM Commodity c WHERE c.name LIKE %:keyword% AND c.price BETWEEN :minPrice AND :maxPrice")
    List<Commodity> findByNameContainingAndPriceBetween(
            @Param("keyword") String keyword,
            @Param("minPrice") Double minPrice,
            @Param("maxPrice") Double maxPrice
    );

    // 复杂查询：统计各类商品的库存总量
    @Query("SELECT c.name, SUM(c.count) FROM Commodity c GROUP BY c.name")
    List<Object[]> countTotalStockByName();

    // 根据库存数量排序
    List<Commodity> findAllByOrderByCountAsc();  // 升序
    List<Commodity> findAllByOrderByCountDesc(); // 降序

    // 根据价格排序
    List<Commodity> findAllByOrderByPriceAsc();  // 升序
    List<Commodity> findAllByOrderByPriceDesc(); // 降序

    // 根据更新时间排序
    List<Commodity> findAllByOrderByUpdateAtDesc();

    // 根据创建时间排序
    List<Commodity> findAllByOrderByCreateAtDesc();

    // 查找价格高于指定值的商品
    List<Commodity> findByPriceGreaterThan(Double price);

    // 查找价格低于指定值的商品
    List<Commodity> findByPriceLessThan(Double price);

    // 根据名称和库存条件查询
    List<Commodity> findByNameContainingAndCountGreaterThan(String name, Integer count);

    // 统计总库存量
    @Query("SELECT SUM(c.count) FROM Commodity c")
    Long sumTotalStock();

    // 统计商品种类数量
    @Query("SELECT COUNT(DISTINCT c.name) FROM Commodity c")
    Long countDistinctNames();
}