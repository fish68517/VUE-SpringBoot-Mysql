package com.example.api.service;

import com.example.api.model.Commodity;

import java.util.List;
import java.util.Optional;

public interface CommodityService {

    Commodity save(Commodity commodity);

    void deleteById(String id);

    Commodity findById(String id);

    List<Commodity> findAll();

    List<Commodity> findAllByNameLike(String name);

    // === 新增的方法 ===

    /**
     * 检查商品是否存在
     */
    boolean existsById(String id);

    /**
     * 根据库存范围查询商品
     */
    List<Commodity> findByCountBetween(Integer minCount, Integer maxCount);

    /**
     * 根据价格范围查询商品
     */
    List<Commodity> findByPriceBetween(Double minPrice, Double maxPrice);

    /**
     * 查找库存低于指定值的商品（用于预警）
     */
    List<Commodity> findByCountLessThan(Integer count);

    /**
     * 查找库存高于指定值的商品（用于预警）
     */
    List<Commodity> findByCountGreaterThan(Integer count);

    /**
     * 获取商品总数
     */
    long count();

    /**
     * 批量删除商品
     */
    void deleteAllById(List<String> ids);

    /**
     * 根据名称模糊搜索（使用Containing）
     */
    List<Commodity> findByNameContaining(String name);

    /**
     * 根据名称精确查找
     */
    Optional<Commodity> findByName(String name);

    /**
     * 根据价格排序（升序）
     */
    List<Commodity> findAllByOrderByPriceAsc();

    /**
     * 根据价格排序（降序）
     */
    List<Commodity> findAllByOrderByPriceDesc();

    /**
     * 根据库存排序（升序）
     */
    List<Commodity> findAllByOrderByCountAsc();

    /**
     * 根据库存排序（降序）
     */
    List<Commodity> findAllByOrderByCountDesc();
}