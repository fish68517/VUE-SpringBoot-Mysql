package com.example.api.exception;

public class AccountAndPasswordError extends Exception{

}
