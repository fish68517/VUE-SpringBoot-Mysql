package com.example.api.task;

/**
 * @description
 * @className TestThread
 * @package com.example.api.task.TestThread
 * @Author zhoutianyong@yuntai.com
 * @date 2023/2/23 0023
 * @copyright 版权归 HSYUNTAI 所有
 * @Path yt-plat-hospital
 * @module
 */
public class TestThread  extends Thread{

}
