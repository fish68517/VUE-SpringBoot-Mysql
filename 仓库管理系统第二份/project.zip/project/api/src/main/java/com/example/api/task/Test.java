package com.example.api.task;

import java.util.HashMap;

/**
 * @description
 * @className Test
 * @package com.example.api.task.Test
 * @Author zhoutianyong@yuntai.com
 * @date 2023/2/23 0023
 * @copyright 版权归 HSYUNTAI 所有
 * @Path yt-plat-hospital
 * @module
 */
public class Test {
    public static void main(String[] args) {

        HashMap<Object, Object> objectObjectHashMap = new HashMap<>();
        objectObjectHashMap.put(null,null);

    }
}
