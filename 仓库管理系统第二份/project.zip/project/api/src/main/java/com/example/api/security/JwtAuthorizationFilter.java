package com.example.api.security;

import com.example.api.model.support.ResponseResult;
import com.example.api.utils.JwtTokenUtil;
import com.example.api.utils.ResponseUtil;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.util.AntPathMatcher;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class JwtAuthorizationFilter extends BasicAuthenticationFilter {

    private static final String[] PERMIT_ALL_PATHS = {
            "/api/auth/**",
            "/api/admin/login",
            "/error"
    };

    private final AntPathMatcher pathMatcher = new AntPathMatcher();

    public JwtAuthorizationFilter(AuthenticationManager authenticationManager) {
        super(authenticationManager);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws IOException, ServletException {

        String requestURI = request.getRequestURI();

        // 检查是否为免认证路径
        if (isPermitAllPath(requestURI)) {
            chain.doFilter(request, response);
            return;
        }

        String token = request.getHeader(JwtTokenUtil.TOKEN_HEADER);

        if (!JwtTokenUtil.checkToken(token)) {
            ResponseUtil.writeJson(response, new ResponseResult<>(401, "请先登录"));
            return;
        }

        if (JwtTokenUtil.isExpiration(token)) {
            ResponseUtil.writeJson(response, new ResponseResult<>(403, "令牌已过期, 请重新登录"));
            return;
        }

        try {
            String username = JwtTokenUtil.getUsername(token);
            List<String> tokenRoles = JwtTokenUtil.getTokenRoles(token);
            List<SimpleGrantedAuthority> authorities = new ArrayList<>();

            // 添加调试信息
            System.out.println("JWT Filter - 解析到的角色: " + tokenRoles);

            if (tokenRoles != null) {
                for (String role : tokenRoles) {
                    // 修复：不再重复添加ROLE_前缀
                    authorities.add(new SimpleGrantedAuthority(role));
                    System.out.println("JWT Filter - 添加权限: " + role);
                }
            }

            UsernamePasswordAuthenticationToken authentication =
                    new UsernamePasswordAuthenticationToken(username, null, authorities);
            SecurityContextHolder.getContext().setAuthentication(authentication);

            System.out.println("JWT Filter - 认证成功: " + username + ", 权限: " + authorities);

        } catch (Exception e) {
            ResponseUtil.writeJson(response, new ResponseResult<>(403, "令牌无效"));
            return;
        }

        chain.doFilter(request, response);
    }

    private boolean isPermitAllPath(String requestURI) {
        for (String pattern : PERMIT_ALL_PATHS) {
            if (pathMatcher.match(pattern, requestURI)) {
                return true;
            }
        }
        return false;
    }
}