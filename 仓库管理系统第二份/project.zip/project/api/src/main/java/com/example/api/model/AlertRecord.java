package com.example.api.model;

import com.example.api.model.enums.AlertType;
import com.example.api.model.enums.AlertLevel;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "alert_records")
public class AlertRecord {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "product_id")
    private String productId;  // 改为String类型

    @Enumerated(EnumType.STRING)
    @Column(name = "alert_type")
    private AlertType alertType;

    @Enumerated(EnumType.STRING)
    @Column(name = "alert_level")
    private AlertLevel alertLevel;

    @Column(name = "current_value")
    private Integer currentValue;

    @Column(name = "threshold_value")
    private Integer thresholdValue;

    private String message;

    @Column(name = "is_resolved")
    private Boolean isResolved = false;

    @Column(name = "resolved_time")
    private Date resolvedTime;

    @Column(name = "resolved_by")
    private Long resolvedBy;

    @Column(name = "created_time")
    private Date createdTime;

    // 默认构造函数
    public AlertRecord() {}

    // 修改构造函数，使用String productId
    public AlertRecord(String productId, AlertType alertType, AlertLevel alertLevel,
                       Integer currentValue, Integer thresholdValue, String message) {
        this.productId = productId;
        this.alertType = alertType;
        this.alertLevel = alertLevel;
        this.currentValue = currentValue;
        this.thresholdValue = thresholdValue;
        this.message = message;
        this.createdTime = new Date();
    }

    // Getter和Setter方法
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getProductId() { return productId; }  // 改为String
    public void setProductId(String productId) { this.productId = productId; }  // 改为String

    public AlertType getAlertType() { return alertType; }
    public void setAlertType(AlertType alertType) { this.alertType = alertType; }

    public AlertLevel getAlertLevel() { return alertLevel; }
    public void setAlertLevel(AlertLevel alertLevel) { this.alertLevel = alertLevel; }

    public Integer getCurrentValue() { return currentValue; }
    public void setCurrentValue(Integer currentValue) { this.currentValue = currentValue; }

    public Integer getThresholdValue() { return thresholdValue; }
    public void setThresholdValue(Integer thresholdValue) { this.thresholdValue = thresholdValue; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public Boolean getIsResolved() { return isResolved; }
    public void setIsResolved(Boolean isResolved) { this.isResolved = isResolved; }

    public Date getResolvedTime() { return resolvedTime; }
    public void setResolvedTime(Date resolvedTime) { this.resolvedTime = resolvedTime; }

    public Long getResolvedBy() { return resolvedBy; }
    public void setResolvedBy(Long resolvedBy) { this.resolvedBy = resolvedBy; }

    public Date getCreatedTime() { return createdTime; }
    public void setCreatedTime(Date createdTime) { this.createdTime = createdTime; }

    // 添加PrePersist方法
    @PrePersist
    protected void onCreate() {
        if (createdTime == null) {
            createdTime = new Date();
        }
    }

    @Override
    public String toString() {
        return "AlertRecord{" +
                "id=" + id +
                ", productId='" + productId + '\'' +
                ", alertType=" + alertType +
                ", alertLevel=" + alertLevel +
                ", currentValue=" + currentValue +
                ", thresholdValue=" + thresholdValue +
                ", message='" + message + '\'' +
                ", isResolved=" + isResolved +
                ", createdTime=" + createdTime +
                '}';
    }
}