package com.example.api.handler;

import com.example.api.model.support.ResponseResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@ResponseBody
@RestControllerAdvice
public class GlobalExceptionHandler {
    private final Logger logger = LoggerFactory.getLogger(getClass());

    @ExceptionHandler(value = Exception.class)
    public Object handleException(Exception e) {
        if (e.getClass().equals(AccessDeniedException.class)) {
            return new ResponseResult<>(403, "你没有访问权限");
        }

        // 打印完整堆栈信息到控制台
        logger.error("捕获异常: {}", e.getClass().getSimpleName(), e);

        String errorMessage = e.getMessage();
        if (errorMessage == null || errorMessage.trim().isEmpty()) {
            errorMessage = "系统内部错误: " + e.getClass().getSimpleName();
        }

        return new ResponseResult<>(400, errorMessage);
    }
}