package com.example.api.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;

@Configuration
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable().cors();
        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);

        // 完整的RBAC权限配置
        http.authorizeRequests()
                .antMatchers("/api/auth/**").permitAll()
                .antMatchers("/api/admin/login").permitAll()
                .antMatchers("/api/admin/hasInit").permitAll()  // ✅ 允许检查初始化状态
                .antMatchers("/api/admin/init").permitAll()     // ✅ 允许初始化注册
                .antMatchers("/api/employee/**").hasAnyRole("SUPER_ADMIN", "EMPLOYEE")
                .antMatchers("/api/warehouse/**").hasAnyRole("SUPER_ADMIN", "WAREHOUSE")
                .antMatchers("/api/sale/**").hasAnyRole("SUPER_ADMIN", "SALE")
                .antMatchers("/api/alerts/**").hasAnyRole("SUPER_ADMIN", "ALERT")
                .antMatchers("/api/commodity/**").hasAnyRole("SUPER_ADMIN", "COMMODITY")
                .antMatchers("/api/admin/**").hasRole("SUPER_ADMIN")
                .anyRequest().authenticated();

        http.addFilter(new JwtAuthorizationFilter(authenticationManagerBean()));
    }

    @Bean
    CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOriginPatterns(Arrays.asList("*"));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(Arrays.asList("*"));
        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}