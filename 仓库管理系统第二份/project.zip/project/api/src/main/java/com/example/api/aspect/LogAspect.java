package com.example.api.aspect;

import com.example.api.annotation.Log;
import com.example.api.model.entity.SystemLog;
import com.example.api.service.SystemLogService;
import com.example.api.utils.IpUtil;
import com.example.api.utils.JwtTokenUtil;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.time.LocalDateTime;

@Aspect
@Component
public class LogAspect {
    @Autowired
    private SystemLogService logService;

    @Pointcut("@annotation(com.example.api.annotation.Log)")
    public void pt(){}

    @Around("pt()")
    public Object Around(ProceedingJoinPoint point) throws Throwable {
        long beginTime = System.currentTimeMillis();
        Object res = null;
        try {
            res = point.proceed();
        } finally {
            long time = System.currentTimeMillis() - beginTime;
            recordLog(point);
        }
        return res;
    }

    private void recordLog(ProceedingJoinPoint point){
        try {
            ServletRequestAttributes requestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (requestAttributes == null) {
                return;
            }

            HttpServletRequest request = requestAttributes.getRequest();
            MethodSignature signature = (MethodSignature) point.getSignature();
            Method method = signature.getMethod();
            Log annotation = method.getAnnotation(Log.class);

            SystemLog systemLog = new SystemLog();
            systemLog.setModule(annotation.moudle());
            systemLog.setBusincessType(annotation.type().getName());
            systemLog.setIp(IpUtil.getIpAddr(request));
            systemLog.setTime(LocalDateTime.now());
            systemLog.setMethod(signature.getDeclaringTypeName()+"."+signature.getName());

            // 修复：添加token空值检查
            String token = request.getHeader(JwtTokenUtil.TOKEN_HEADER);
            if (token != null && JwtTokenUtil.checkToken(token)) {
                try {
                    systemLog.setAccount(JwtTokenUtil.getUsername(token));
                } catch (Exception e) {
                    systemLog.setAccount("未知用户");
                }
            } else {
                systemLog.setAccount("匿名用户");
            }

            logService.record(systemLog);

        } catch (Exception e) {
            System.out.println("记录日志异常: " + e.getMessage());
        }
    }
}