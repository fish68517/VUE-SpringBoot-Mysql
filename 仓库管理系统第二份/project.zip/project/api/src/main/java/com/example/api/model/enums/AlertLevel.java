package com.example.api.model.enums;

public enum AlertLevel {
    LOW,    // 低风险
    MEDIUM, // 中风险
    HIGH    // 高风险
}