package com.example.api.service.impl;

import com.example.api.model.AlertRecord;
import com.example.api.model.AlertRule;
import com.example.api.model.Commodity;
import com.example.api.model.enums.AlertLevel;
import com.example.api.model.enums.AlertType;
import com.example.api.repository.AlertRecordRepository;
import com.example.api.repository.AlertRuleRepository;
import com.example.api.repository.CommodityRepository;
import com.example.api.service.AlertNotificationService;
import com.example.api.service.AlertService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import javax.annotation.PostConstruct;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class AlertServiceImpl implements AlertService {

    @Autowired
    private AlertRuleRepository alertRuleRepository;

    @Autowired
    private AlertRecordRepository alertRecordRepository;

    @Autowired
    private AlertNotificationService alertNotificationService;

    @Autowired
    private CommodityRepository commodityRepository;

    /**
     * 检查所有商品的库存预警（每5分钟执行一次）
     */
    @Scheduled(cron = "0 0/5 * * * ?")
    @Transactional
    @Override
    public void checkInventoryAlerts() {
        log.info("开始执行库存预警检查...");

        try {
            // 1. 获取所有启用的预警规则
            List<AlertRule> activeRules = alertRuleRepository.findByIsActiveTrue();
            if (activeRules.isEmpty()) {
                log.info("没有启用的预警规则，跳过检查");
                return;
            }

            // 2. 按商品ID分组规则
            Map<String, List<AlertRule>> rulesByProduct = activeRules.stream()  // 改为String
                    .collect(Collectors.groupingBy(AlertRule::getProductId));

            // 3. 检查每个商品的预警条件
            for (Map.Entry<String, List<AlertRule>> entry : rulesByProduct.entrySet()) {
                String productId = entry.getKey();  // 改为String
                List<AlertRule> productRules = entry.getValue();

                // 获取商品当前库存 - 从数据库获取真实数据
                Integer currentStock = getRealStockByProductId(productId);
                if (currentStock == null) {
                    log.warn("无法获取商品ID: {} 的库存数据", productId);
                    continue;
                }

                // 检查该商品的所有规则
                checkProductAlerts(productId, currentStock, productRules);
            }

            log.info("库存预警检查完成，检查了 {} 个商品的规则", rulesByProduct.size());

        } catch (Exception e) {
            log.error("库存预警检查异常", e);
        }
    }

    /**
     * 获取商品真实库存数量 - 从数据库获取
     */
    private Integer getRealStockByProductId(String productId) {  // 改为String
        try {
            // 从数据库查询商品信息
            Optional<Commodity> commodity = commodityRepository.findById(productId);  // 直接使用String ID
            if (commodity.isPresent()) {
                Commodity product = commodity.get();
                Integer stock = product.getCount();
                String productName = product.getName();

                // 详细的调试信息
                log.info("📊 数据库查询详情 - 商品ID: {}, 商品名称: '{}', 库存: {}, 名称是否为空: {}",
                        productId, productName, stock, (productName == null || productName.trim().isEmpty()));

                return stock;
            } else {
                log.warn("⚠️ 未找到商品ID: {} 的数据库记录", productId);
                return 0;
            }

        } catch (Exception e) {
            log.error("❌ 获取商品库存失败 - 商品ID: {}", productId, e);
            return null;
        }
    }

    /**
     * 获取商品名称 - 从数据库获取（增强版本）
     */
    private String getProductName(String productId) {  // 改为String
        try {
            // 从数据库查询商品名称
            Optional<Commodity> commodity = commodityRepository.findById(productId);  // 直接使用String ID
            if (commodity.isPresent()) {
                Commodity product = commodity.get();
                String productName = product.getName();

                // 检查名称是否为空或空白
                if (productName == null || productName.trim().isEmpty()) {
                    log.warn("🚨 商品ID: {} 的名称为空或空白，使用默认名称", productId);
                    return "未命名商品(ID:" + productId + ")";
                }

                // 记录成功获取的名称
                log.debug("✅ 成功获取商品名称 - ID: {}, 名称: {}", productId, productName);
                return productName;

            } else {
                log.warn("⚠️ 未找到商品ID: {} 的数据库记录", productId);
                return "未知商品(ID:" + productId + ")";
            }

        } catch (Exception e) {
            log.error("❌ 获取商品名称失败 - 商品ID: {}", productId, e);
            return "商品ID:" + productId;  // 第88行修复 - 现在productId已经是String了
        }
    }

    /**
     * 检查单个商品的预警
     */
    private void checkProductAlerts(String productId, Integer currentStock, List<AlertRule> rules) {  // 改为String
        for (AlertRule rule : rules) {
            switch (rule.getRuleType()) {
                case LOW_STOCK:
                    checkLowStockAlert(productId, currentStock, rule);
                    break;
                case OVER_STOCK:
                    checkOverStockAlert(productId, currentStock, rule);
                    break;
            }
        }
    }

    /**
     * 检查低库存预警（增强版本）
     */
    private void checkLowStockAlert(String productId, Integer currentStock, AlertRule rule) {  // 改为String
        if (rule.getMinStock() != null && currentStock <= rule.getMinStock()) {
            // 计算预警级别
            AlertLevel level = calculateLowStockLevel(currentStock, rule.getMinStock());

            // 获取商品名称（确保在日志和消息中使用）
            String productName = getProductName(productId);

            // 创建预警记录
            AlertRecord alert = new AlertRecord();
            alert.setProductId(productId);  // 使用String ID
            alert.setAlertType(AlertType.LOW_STOCK);
            alert.setAlertLevel(level);
            alert.setCurrentValue(currentStock);
            alert.setThresholdValue(rule.getMinStock());
            alert.setMessage(String.format(
                    "商品【%s】库存过低！当前库存：%d，安全库存：%d",
                    productName, currentStock, rule.getMinStock()
            ));

            // 保存预警记录（避免重复）
            if (!isDuplicateAlert(alert)) {
                alertRecordRepository.save(alert);
                log.warn("🚨 低库存预警 - 商品: {}, 当前库存: {}, 安全库存: {}, 预警级别: {}",
                        productName, currentStock, rule.getMinStock(), level);

                // 发送邮件通知
                try {
                    alertNotificationService.sendLowStockAlert(
                            productName,
                            currentStock,
                            rule.getMinStock(),
                            level
                    );
                } catch (Exception e) {
                    log.error("发送低库存预警邮件失败", e);
                }
            }
        }
    }

    /**
     * 检查高库存预警（增强版本）
     */
    private void checkOverStockAlert(String productId, Integer currentStock, AlertRule rule) {  // 改为String
        if (rule.getMaxStock() != null && currentStock >= rule.getMaxStock()) {
            AlertLevel level = calculateOverStockLevel(currentStock, rule.getMaxStock());

            // 获取商品名称（确保在日志和消息中使用）
            String productName = getProductName(productId);

            AlertRecord alert = new AlertRecord();
            alert.setProductId(productId);  // 使用String ID
            alert.setAlertType(AlertType.OVER_STOCK);
            alert.setAlertLevel(level);
            alert.setCurrentValue(currentStock);
            alert.setThresholdValue(rule.getMaxStock());
            alert.setMessage(String.format(
                    "商品【%s】库存积压！当前库存：%d，最大库存：%d",
                    productName, currentStock, rule.getMaxStock()
            ));

            if (!isDuplicateAlert(alert)) {
                alertRecordRepository.save(alert);
                log.warn("🚨 高库存预警 - 商品: {}, 当前库存: {}, 最大库存: {}, 预警级别: {}",
                        productName, currentStock, rule.getMaxStock(), level);

                // 发送邮件通知
                try {
                    alertNotificationService.sendOverStockAlert(
                            productName,
                            currentStock,
                            rule.getMaxStock(),
                            level
                    );
                } catch (Exception e) {
                    log.error("发送高库存预警邮件失败", e);
                }
            }
        }
    }

    /**
     * 计算低库存预警级别
     */
    private AlertLevel calculateLowStockLevel(Integer currentStock, Integer minStock) {
        if (minStock == 0) return AlertLevel.MEDIUM;

        double ratio = (double) currentStock / minStock;
        if (ratio <= 0.3) return AlertLevel.HIGH;
        if (ratio <= 0.6) return AlertLevel.MEDIUM;
        return AlertLevel.LOW;
    }

    /**
     * 计算高库存预警级别
     */
    private AlertLevel calculateOverStockLevel(Integer currentStock, Integer maxStock) {
        double ratio = (double) currentStock / maxStock;
        if (ratio >= 2.0) return AlertLevel.HIGH;
        if (ratio >= 1.5) return AlertLevel.MEDIUM;
        return AlertLevel.LOW;
    }

    /**
     * 检查是否重复预警
     */
    private boolean isDuplicateAlert(AlertRecord newAlert) {
        return alertRecordRepository.existsUnresolvedAlert(
                newAlert.getProductId(),
                newAlert.getAlertType()
        );
    }

    /**
     * 手动触发预警检查
     */
    @Override
    public void triggerManualCheck() {
        log.info("手动触发库存预警检查");
        checkInventoryAlerts();
    }

    /**
     * 获取未处理的预警数量
     */
    @Override
    public long getUnresolvedAlertCount() {
        return alertRecordRepository.findByIsResolvedFalseOrderByCreatedTimeDesc().size();
    }

    /**
     * 处理预警（标记为已解决）
     */
    @Override
    @Transactional
    public boolean resolveAlert(Long alertId, Long resolvedBy) {
        try {
            AlertRecord alert = alertRecordRepository.findById(alertId)
                    .orElseThrow(() -> new RuntimeException("预警记录不存在"));

            alert.setIsResolved(true);
            alert.setResolvedTime(new Date());
            alert.setResolvedBy(resolvedBy);

            alertRecordRepository.save(alert);
            log.info("✅ 预警已处理 - 预警ID: {}, 处理人: {}", alertId, resolvedBy);
            return true;

        } catch (Exception e) {
            log.error("处理预警失败 - 预警ID: {}", alertId, e);
            return false;
        }
    }

    /**
     * 获取预警统计信息
     */
    @Override
    public Map<String, Long> getAlertStats() {
        Map<String, Long> stats = new HashMap<>();

        List<AlertRecord> unresolvedAlerts = alertRecordRepository.findByIsResolvedFalseOrderByCreatedTimeDesc();
        stats.put("total", (long) unresolvedAlerts.size());
        stats.put("high", unresolvedAlerts.stream().filter(a -> a.getAlertLevel() == AlertLevel.HIGH).count());
        stats.put("medium", unresolvedAlerts.stream().filter(a -> a.getAlertLevel() == AlertLevel.MEDIUM).count());
        stats.put("low", unresolvedAlerts.stream().filter(a -> a.getAlertLevel() == AlertLevel.LOW).count());

        return stats;
    }

    /**
     * 初始化一些测试预警规则
     */
    @PostConstruct
    public void initTestRules() {
        // 检查是否已有规则，如果没有就创建一些测试规则
        if (alertRuleRepository.count() == 0) {
            log.info("初始化测试预警规则...");

            // 创建一些测试规则 - 使用真实的商品UUID
            List<AlertRule> testRules = Arrays.asList(
                    new AlertRule("1c0e25d3-db1f-4cda-93b1-81101d21dc5b", AlertType.LOW_STOCK, 50, 200),   // iphone17promax1TB
                    new AlertRule("2", AlertType.LOW_STOCK, 10, 50),    // 富士高端相机
                    new AlertRule("2757278d-fb76-496a-8bd1-7629fa6baf00", AlertType.LOW_STOCK, 15, 100),   // 富士相机
                    new AlertRule("3ce4732f-61e1-4048-beb7-89dd7b3d99dc", AlertType.LOW_STOCK, 10, 80),    // 小米15pro
                    new AlertRule("7", AlertType.LOW_STOCK, 5, null),   // 苹果16promax
                    new AlertRule("8", AlertType.OVER_STOCK, null, 30)  // 盒马面包
            );

            alertRuleRepository.saveAll(testRules);
            log.info("测试预警规则初始化完成，共创建 {} 条规则", testRules.size());
        } else {
            log.info("已有预警规则，跳过初始化");
            // 检查当前规则数量
            long ruleCount = alertRuleRepository.count();
            log.info("当前有 {} 条预警规则", ruleCount);
        }
    }

    /**
     * 新增：为新商品创建默认预警规则
     */
    public void createDefaultRuleForNewProduct(String productId, String productName) {  // 改为String
        try {
            // 检查是否已有该商品的规则
            List<AlertRule> existingRules = alertRuleRepository.findByProductId(productId);
            if (existingRules.isEmpty()) {
                // 创建默认预警规则
                AlertRule defaultRule = new AlertRule(
                        productId,
                        AlertType.LOW_STOCK,
                        10,  // 默认低库存阈值
                        100  // 默认高库存阈值
                );
                alertRuleRepository.save(defaultRule);
                log.info("✅ 为新商品创建默认预警规则 - 商品: {} (ID: {})", productName, productId);
            } else {
                log.info("商品 {} (ID: {}) 已有预警规则，跳过创建", productName, productId);
            }
        } catch (Exception e) {
            log.error("为新商品创建预警规则失败 - 商品ID: {}, 商品名称: {}", productId, productName, e);
        }
    }

    /**
     * 新增：获取所有有预警规则的商品ID列表
     */
    public List<String> getProductsWithRules() {  // 改为String
        return alertRuleRepository.findByIsActiveTrue()
                .stream()
                .map(AlertRule::getProductId)
                .distinct()
                .collect(Collectors.toList());
    }

    /**
     * 新增：检查商品是否存在
     */
    public boolean isProductExists(String productId) {  // 改为String
        return commodityRepository.existsById(productId);
    }

    /**
     * 新增：获取所有商品信息（用于调试）
     */
    public List<Commodity> getAllCommodities() {
        return commodityRepository.findAll();
    }

    /**
     * 新增：调试方法 - 检查特定商品的详细信息
     */
    public void debugProductInfo(String productId) {  // 改为String
        try {
            Optional<Commodity> commodity = commodityRepository.findById(productId);
            if (commodity.isPresent()) {
                Commodity product = commodity.get();
                log.info("🔍 商品调试信息 - ID: {}, 名称: '{}', 库存: {}, 价格: {}, 描述: '{}'",
                        product.getId(), product.getName(), product.getCount(),
                        product.getPrice(), product.getDescription());
            } else {
                log.warn("🔍 调试: 未找到商品ID: {}", productId);
            }
        } catch (Exception e) {
            log.error("🔍 调试失败 - 商品ID: {}", productId, e);
        }
    }
}