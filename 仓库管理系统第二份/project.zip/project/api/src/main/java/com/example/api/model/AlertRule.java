package com.example.api.model;

import com.example.api.model.enums.AlertType;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "alert_rules")
public class AlertRule {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "product_id")
    private String productId;  // 已改为String类型

    @Enumerated(EnumType.STRING)
    @Column(name = "rule_type")
    private AlertType ruleType;

    @Column(name = "min_stock")
    private Integer minStock;

    @Column(name = "max_stock")
    private Integer maxStock;

    @Column(name = "is_active")
    private Boolean isActive = true;

    @Column(name = "created_time")
    private Date createdTime;

    @Column(name = "updated_time")
    private Date updatedTime;

    // 默认构造函数
    public AlertRule() {}

    // 修改构造函数，使用String productId
    public AlertRule(String productId, AlertType ruleType, Integer minStock, Integer maxStock) {
        this.productId = productId;
        this.ruleType = ruleType;
        this.minStock = minStock;
        this.maxStock = maxStock;
        this.createdTime = new Date();
        this.updatedTime = new Date();
    }

    // Getter和Setter方法
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getProductId() { return productId; }
    public void setProductId(String productId) { this.productId = productId; }

    public AlertType getRuleType() { return ruleType; }
    public void setRuleType(AlertType ruleType) { this.ruleType = ruleType; }

    public Integer getMinStock() { return minStock; }
    public void setMinStock(Integer minStock) { this.minStock = minStock; }

    public Integer getMaxStock() { return maxStock; }
    public void setMaxStock(Integer maxStock) { this.maxStock = maxStock; }

    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }

    public Date getCreatedTime() { return createdTime; }
    public void setCreatedTime(Date createdTime) { this.createdTime = createdTime; }

    public Date getUpdatedTime() { return updatedTime; }
    public void setUpdatedTime(Date updatedTime) { this.updatedTime = updatedTime; }

    // 添加PrePersist和PreUpdate方法
    @PrePersist
    protected void onCreate() {
        createdTime = new Date();
        updatedTime = new Date();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedTime = new Date();
    }

    @Override
    public String toString() {
        return "AlertRule{" +
                "id=" + id +
                ", productId='" + productId + '\'' +
                ", ruleType=" + ruleType +
                ", minStock=" + minStock +
                ", maxStock=" + maxStock +
                ", isActive=" + isActive +
                ", createdTime=" + createdTime +
                ", updatedTime=" + updatedTime +
                '}';
    }
}