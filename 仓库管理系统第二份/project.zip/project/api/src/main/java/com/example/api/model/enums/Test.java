package com.example.api.model.enums;

public class Test {
    public static void main(String[] args) {
    }
}
