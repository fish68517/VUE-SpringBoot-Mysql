package com.example.api.controller;

import com.example.api.model.AlertRecord;
import com.example.api.service.AlertNotificationService;
import com.example.api.service.AlertService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/alerts")
@PreAuthorize("hasAnyRole('ROLE_SUPER_ADMIN', 'ROLE_ALERT')")  // 添加这行
public class AlertController {

    @Autowired
    private AlertService alertService;

    @Autowired
    private com.example.api.repository.AlertRecordRepository alertRecordRepository;

    @Autowired
    private AlertNotificationService alertNotificationService;

    /**
     * 获取所有未处理的预警列表
     */
    @GetMapping("/active")
    public Map<String, Object> getActiveAlerts() {
        List<AlertRecord> alerts = alertRecordRepository.findByIsResolvedFalseOrderByCreatedTimeDesc();

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("data", alerts);
        result.put("total", alerts.size());
        return result;
    }

    /**
     * 获取高优先级预警
     */
    @GetMapping("/high-priority")
    public Map<String, Object> getHighPriorityAlerts() {
        List<AlertRecord> alerts = alertRecordRepository.findHighPriorityAlerts();

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("data", alerts);
        return result;
    }

    /**
     * 获取预警统计信息
     */
    @GetMapping("/stats")
    public Map<String, Object> getAlertStats() {
        Map<String, Long> stats = alertService.getAlertStats();

        Map<String, Object> result = new HashMap<>();
        result.put("success", true);
        result.put("data", stats);
        return result;
    }

    /**
     * 处理预警（标记为已解决）
     */
    @PostMapping("/{alertId}/resolve")
    public Map<String, Object> resolveAlert(@PathVariable Long alertId, @RequestBody Map<String, Object> request) {
        try {
            Long resolvedBy = Long.valueOf(request.get("resolvedBy").toString());
            boolean success = alertService.resolveAlert(alertId, resolvedBy);

            Map<String, Object> result = new HashMap<>();
            if (success) {
                result.put("success", true);
                result.put("message", "预警已处理");
            } else {
                result.put("success", false);
                result.put("message", "处理失败");
            }
            return result;

        } catch (Exception e) {
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("message", "处理失败: " + e.getMessage());
            return result;
        }
    }

    /**
     * 手动触发预警检查
     */
    @PostMapping("/check-now")
    public Map<String, Object> triggerAlertCheck() {
        try {
            alertService.triggerManualCheck();

            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("message", "预警检查已完成");
            return result;

        } catch (Exception e) {
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("message", "检查失败: " + e.getMessage());
            return result;
        }
    }

    /**
     * 测试邮件发送功能
     */
    @PostMapping("/test-email")
    public Map<String, Object> testEmail() {
        try {
            alertNotificationService.sendTestEmail();

            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("message", "测试邮件发送成功，请检查邮箱");
            return result;

        } catch (Exception e) {
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("message", "测试邮件发送失败: " + e.getMessage());
            return result;
        }
    }

    /**
     * 发送自定义测试邮件
     */
    @PostMapping("/test-email-custom")
    public Map<String, Object> testCustomEmail(@RequestBody Map<String, String> request) {
        try {
            String subject = request.getOrDefault("subject", "【测试】自定义邮件主题");
            String content = request.getOrDefault("content", "这是一封自定义测试邮件内容");

            alertNotificationService.sendSimpleAlertEmail(subject, content);

            Map<String, Object> result = new HashMap<>();
            result.put("success", true);
            result.put("message", "自定义测试邮件发送成功");
            return result;

        } catch (Exception e) {
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("message", "自定义测试邮件发送失败: " + e.getMessage());
            return result;
        }
    }
}