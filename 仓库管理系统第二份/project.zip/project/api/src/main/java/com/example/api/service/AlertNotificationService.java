package com.example.api.service;

import com.example.api.model.enums.AlertLevel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.internet.MimeMessage;

@Service
@Slf4j
public class AlertNotificationService {

    @Autowired
    private JavaMailSender mailSender;

    @Value("${spring.mail.username}")
    private String fromEmail;

    @Value("${alert.notification.email.to:2361471705@qq.com}")
    private String toEmail;

    @Value("${alert.notification.email.enabled:true}")
    private boolean emailEnabled;

    /**
     * 发送简单文本预警邮件
     */
    public void sendSimpleAlertEmail(String subject, String content) {
        if (!emailEnabled) {
            log.info("邮件通知未启用，跳过发送");
            return;
        }

        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(toEmail);
            message.setSubject(subject);
            message.setText(content);

            mailSender.send(message);
            log.info("预警邮件发送成功 - 主题: {}", subject);
        } catch (Exception e) {
            log.error("发送预警邮件失败", e);
        }
    }

    /**
     * 发送HTML格式的预警邮件
     */
    public void sendHtmlAlertEmail(String subject, String htmlContent) {
        if (!emailEnabled) {
            log.info("邮件通知未启用，跳过发送");
            return;
        }

        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setFrom(fromEmail);
            helper.setTo(toEmail);
            helper.setSubject(subject);
            helper.setText(htmlContent, true);

            mailSender.send(message);
            log.info("HTML预警邮件发送成功 - 主题: {}", subject);
        } catch (Exception e) {
            log.error("发送HTML预警邮件失败", e);
            // 失败时尝试发送简单邮件
            sendSimpleAlertEmail(subject, "库存预警通知 - 请登录系统查看详情");
        }
    }

    /**
     * 发送低库存预警邮件
     */
    public void sendLowStockAlert(String productName, Integer currentStock, Integer minStock, AlertLevel level) {
        String subject = String.format("【低库存预警】%s - %s级别", productName, getLevelDisplayName(level));

        String htmlContent = buildAlertEmailHtml(
                "低库存预警",
                productName,
                currentStock,
                minStock,
                null,
                getLevelDisplayName(level),
                String.format("商品 %s 库存过低！当前库存：%d，安全库存：%d", productName, currentStock, minStock)
        );

        sendHtmlAlertEmail(subject, htmlContent);
    }

    /**
     * 发送高库存预警邮件
     */
    public void sendOverStockAlert(String productName, Integer currentStock, Integer maxStock, AlertLevel level) {
        String subject = String.format("【高库存预警】%s - %s级别", productName, getLevelDisplayName(level));

        String htmlContent = buildAlertEmailHtml(
                "高库存预警",
                productName,
                currentStock,
                null,
                maxStock,
                getLevelDisplayName(level),
                String.format("商品 %s 库存积压！当前库存：%d，最大库存：%d", productName, currentStock, maxStock)
        );

        sendHtmlAlertEmail(subject, htmlContent);
    }

    /**
     * 构建预警邮件HTML内容
     */
    private String buildAlertEmailHtml(String alertType, String productName, Integer currentStock,
                                       Integer minStock, Integer maxStock, String alertLevel, String message) {
        String levelColor = getLevelColor(alertLevel);

        return "<!DOCTYPE html>" +
                "<html>" +
                "<head>" +
                "<meta charset=\"UTF-8\">" +
                "<title>库存预警通知</title>" +
                "<style>" +
                "body { font-family: 'Microsoft YaHei', Arial, sans-serif; margin: 20px; line-height: 1.6; background: #f5f5f5; }" +
                ".container { max-width: 600px; margin: 0 auto; background: #ffffff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }" +
                ".header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 8px 8px 0 0; text-align: center; }" +
                ".alert { border-left: 4px solid " + levelColor + "; padding: 15px; margin: 15px 0; background: #f8f9fa; border-radius: 4px; }" +
                ".footer { margin-top: 20px; padding-top: 20px; border-top: 1px solid #eee; text-align: center; color: #666; font-size: 12px; }" +
                ".btn { display: inline-block; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 4px; margin: 10px 0; }" +
                ".info-item { margin: 8px 0; }" +
                ".info-label { font-weight: bold; color: #333; }" +
                "</style>" +
                "</head>" +
                "<body>" +
                "<div class=\"container\">" +
                "<div class=\"header\">" +
                "<h1>📊 库存预警通知</h1>" +
                "<p>库存管理系统自动预警</p>" +
                "</div>" +
                "<div class=\"alert\">" +
                "<h3>" + alertType + " - " + alertLevel + "级别</h3>" +
                "<div class=\"info-item\"><span class=\"info-label\">商品名称:</span> " + productName + "</div>" +
                "<div class=\"info-item\"><span class=\"info-label\">当前库存:</span> " + currentStock + "</div>" +
                (minStock != null ? "<div class=\"info-item\"><span class=\"info-label\">安全库存:</span> " + minStock + "</div>" : "") +
                (maxStock != null ? "<div class=\"info-item\"><span class=\"info-label\">最大库存:</span> " + maxStock + "</div>" : "") +
                "<div class=\"info-item\"><span class=\"info-label\">预警信息:</span> " + message + "</div>" +
                "</div>" +
                "<div style=\"text-align: center; margin: 20px 0;\">" +
                "<a href=\"http://localhost:8080/alerts\" class=\"btn\">立即处理预警</a>" +
                "</div>" +
                "<div class=\"footer\">" +
                "<p>此邮件由库存预警系统自动发送，请勿回复</p>" +
                "<p>如有问题，请联系系统管理员</p>" +
                "</div>" +
                "</div>" +
                "</body>" +
                "</html>";
    }

    /**
     * 根据预警级别获取颜色
     */
    private String getLevelColor(String alertLevel) {
        switch (alertLevel) {
            case "高风险": return "#ff4444";
            case "中风险": return "#ffaa00";
            case "低风险": return "#00aa00";
            default: return "#666666";
        }
    }

    /**
     * 获取预警级别显示名称
     */
    private String getLevelDisplayName(AlertLevel level) {
        switch (level) {
            case HIGH: return "高风险";
            case MEDIUM: return "中风险";
            case LOW: return "低风险";
            default: return "未知";
        }
    }

    /**
     * 测试邮件发送
     */
    public void sendTestEmail() {
        String subject = "【测试】库存预警系统邮件通知测试";
        String content = "这是一封测试邮件，用于验证库存预警系统的邮件通知功能是否正常工作。\n\n如果收到此邮件，说明邮件配置正确！";

        sendSimpleAlertEmail(subject, content);
    }
}