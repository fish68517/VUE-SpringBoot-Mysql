package com.example.api.service.impl;

import com.example.api.model.Commodity;
import com.example.api.repository.CommodityRepository;
import com.example.api.service.CommodityService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CommodityServiceImpl implements CommodityService {

    private final CommodityRepository commodityRepository;

    public CommodityServiceImpl(CommodityRepository commodityRepository) {
        this.commodityRepository = commodityRepository;
    }

    @Override
    public Commodity save(Commodity commodity) {
        return commodityRepository.save(commodity);
    }

    @Override
    public void deleteById(String id) {
        commodityRepository.deleteById(id);
    }

    @Override
    public Commodity findById(String id) {
        return commodityRepository.findById(id)
                .orElse(null); // 或者抛出异常
    }

    @Override
    public List<Commodity> findAll() {
        return commodityRepository.findAll();
    }

    @Override
    public List<Commodity> findAllByNameLike(String name) {
        return commodityRepository.findAllByNameLike(name);
    }

    // === 实现新增的方法 ===

    @Override
    public boolean existsById(String id) {
        return commodityRepository.existsById(id);
    }

    @Override
    public List<Commodity> findByCountBetween(Integer minCount, Integer maxCount) {
        return commodityRepository.findByCountBetween(minCount, maxCount);
    }

    @Override
    public List<Commodity> findByPriceBetween(Double minPrice, Double maxPrice) {
        return commodityRepository.findByPriceBetween(minPrice, maxPrice);
    }

    @Override
    public List<Commodity> findByCountLessThan(Integer count) {
        return commodityRepository.findByCountLessThan(count);
    }

    @Override
    public List<Commodity> findByCountGreaterThan(Integer count) {
        return commodityRepository.findByCountGreaterThan(count);
    }

    @Override
    public long count() {
        return commodityRepository.count();
    }

    @Override
    public void deleteAllById(List<String> ids) {
        commodityRepository.deleteAllById(ids);
    }

    @Override
    public List<Commodity> findByNameContaining(String name) {
        return commodityRepository.findByNameContaining(name);
    }

    @Override
    public Optional<Commodity> findByName(String name) {
        return commodityRepository.findByName(name);
    }

    @Override
    public List<Commodity> findAllByOrderByPriceAsc() {
        return commodityRepository.findAllByOrderByPriceAsc();
    }

    @Override
    public List<Commodity> findAllByOrderByPriceDesc() {
        return commodityRepository.findAllByOrderByPriceDesc();
    }

    @Override
    public List<Commodity> findAllByOrderByCountAsc() {
        return commodityRepository.findAllByOrderByCountAsc();
    }

    @Override
    public List<Commodity> findAllByOrderByCountDesc() {
        return commodityRepository.findAllByOrderByCountDesc();
    }
}