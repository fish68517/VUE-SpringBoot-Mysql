package com.example.api.model;

import lombok.Data;
import javax.persistence.*;
import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "commodity")
@Data
public class Commodity {

    @Id
    private String id;

    @Column(name = "name")
    private String name;

    @Column(name = "count")
    private Integer count;

    @Column(name = "price")
    private Double price;

    @Column(name = "description")
    private String description;

    @Column(name = "create_at")
    private String createAt;

    @Column(name = "update_at")
    private String updateAt;

    // 默认构造函数 - 自动生成UUID
    public Commodity() {
        this.id = UUID.randomUUID().toString();
        this.createAt = new Date().toString();
        this.updateAt = new Date().toString();
    }

    // 带参数的构造函数
    public Commodity(String name, Integer count, Double price) {
        this();
        this.name = name;
        this.count = count;
        this.price = price;
    }

    // 带所有参数的构造函数（包括ID）
    public Commodity(String id, String name, Integer count, Double price, String description) {
        this.id = id;
        this.name = name;
        this.count = count;
        this.price = price;
        this.description = description;
        this.createAt = new Date().toString();
        this.updateAt = new Date().toString();
    }

    // 在保存前自动设置创建时间和更新时间
    @PrePersist
    public void prePersist() {
        if (this.createAt == null) {
            this.createAt = new Date().toString();
        }
        if (this.updateAt == null) {
            this.updateAt = new Date().toString();
        }
        // 如果ID为空，自动生成UUID
        if (this.id == null || this.id.trim().isEmpty()) {
            this.id = UUID.randomUUID().toString();
        }
    }

    @PreUpdate
    public void preUpdate() {
        this.updateAt = new Date().toString();
    }

    // Getter 和 Setter 方法 (Lombok的@Data会自动生成，这里显式写出以防万一)
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
        this.updateAt = new Date().toString(); // 更新修改时间
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
        this.updateAt = new Date().toString(); // 更新修改时间
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
        this.updateAt = new Date().toString(); // 更新修改时间
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
        this.updateAt = new Date().toString(); // 更新修改时间
    }

    public String getCreateAt() {
        return createAt;
    }

    public void setCreateAt(String createAt) {
        this.createAt = createAt;
    }

    public String getUpdateAt() {
        return updateAt;
    }

    public void setUpdateAt(String updateAt) {
        this.updateAt = updateAt;
    }

    @Override
    public String toString() {
        return "Commodity{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", count=" + count +
                ", price=" + price +
                ", description='" + description + '\'' +
                ", createAt='" + createAt + '\'' +
                ", updateAt='" + updateAt + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Commodity commodity = (Commodity) o;
        return id != null && id.equals(commodity.id);
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}