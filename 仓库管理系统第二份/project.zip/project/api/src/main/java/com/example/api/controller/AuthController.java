package com.example.api.controller;

import com.example.api.model.dto.LoginDto;
import com.example.api.model.entity.Admin;
import com.example.api.service.AdminService;
import com.example.api.utils.JwtTokenUtil;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AdminService adminService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        try {
            LoginDto loginDto = new LoginDto();
            loginDto.setEmail(loginRequest.getEmail());
            loginDto.setPassword(loginRequest.getPassword());

            Admin admin = adminService.loginByPassword(loginDto);

            if (admin != null) {
                // 生成JWT token
                String token = adminService.createToken(admin, JwtTokenUtil.REMEMBER_EXPIRATION_TIME);

                Map<String, Object> userInfo = new HashMap<>();
                userInfo.put("id", admin.getId());
                userInfo.put("email", admin.getEmail());
                userInfo.put("roles", admin.getRoles());

                Map<String, Object> response = new HashMap<>();
                response.put("success", true);
                response.put("token", token);
                response.put("user", userInfo);
                response.put("message", "登录成功");

                return ResponseEntity.ok(response);
            } else {
                Map<String, Object> response = new HashMap<>();
                response.put("success", false);
                response.put("message", "用户名或密码错误");
                return ResponseEntity.status(401).body(response);
            }
        } catch (Exception e) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "登录失败: " + e.getMessage());
            return ResponseEntity.status(500).body(response);
        }
    }

    @Data
    public static class LoginRequest {
        private String email;
        private String password;
    }
}