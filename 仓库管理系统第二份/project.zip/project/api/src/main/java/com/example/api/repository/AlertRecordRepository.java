package com.example.api.repository;

import com.example.api.model.AlertRecord;
import com.example.api.model.enums.AlertType;
import com.example.api.model.enums.AlertLevel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AlertRecordRepository extends JpaRepository<AlertRecord, Long> {

    /**
     * 查找所有未处理的预警记录，按创建时间倒序
     */
    List<AlertRecord> findByIsResolvedFalseOrderByCreatedTimeDesc();

    /**
     * 根据商品ID查找未处理的预警记录 - 改为String
     */
    List<AlertRecord> findByProductIdAndIsResolvedFalse(String productId);

    /**
     * 检查是否存在未处理的相同预警 - 改为String
     */
    @Query("SELECT COUNT(a) > 0 FROM AlertRecord a WHERE a.productId = :productId " +
            "AND a.alertType = :alertType AND a.isResolved = false")
    boolean existsUnresolvedAlert(@Param("productId") String productId,
                                  @Param("alertType") AlertType alertType);

    /**
     * 查找高优先级未处理预警
     */
    @Query("SELECT a FROM AlertRecord a WHERE a.isResolved = false " +
            "AND a.alertLevel = 'HIGH' ORDER BY a.createdTime DESC")
    List<AlertRecord> findHighPriorityAlerts();

    /**
     * 统计各类预警数量
     */
    @Query("SELECT a.alertType, COUNT(a) FROM AlertRecord a WHERE a.isResolved = false GROUP BY a.alertType")
    List<Object[]> countAlertsByType();

    // === 新增的实用查询方法 ===

    /**
     * 根据商品ID查找预警记录 - 新增方法
     */
    List<AlertRecord> findByProductId(String productId);

    /**
     * 根据商品ID和预警类型查找 - 新增方法
     */
    List<AlertRecord> findByProductIdAndAlertType(String productId, AlertType alertType);

    /**
     * 根据商品ID列表查找预警记录 - 新增方法
     */
    List<AlertRecord> findByProductIdIn(List<String> productIds);

    /**
     * 根据预警类型查找 - 新增方法
     */
    List<AlertRecord> findByAlertType(AlertType alertType);

    /**
     * 根据预警级别查找 - 新增方法
     */
    List<AlertRecord> findByAlertLevel(AlertLevel alertLevel);

    /**
     * 根据预警级别和解决状态查找 - 新增方法
     */
    List<AlertRecord> findByAlertLevelAndIsResolved(AlertLevel alertLevel, Boolean isResolved);

    /**
     * 统计未处理预警数量 - 新增方法
     */
    long countByIsResolvedFalse();

    /**
     * 根据预警类型统计未处理预警数量 - 新增方法
     */
    long countByAlertTypeAndIsResolvedFalse(AlertType alertType);

    /**
     * 根据预警级别统计未处理预警数量 - 新增方法
     */
    long countByAlertLevelAndIsResolvedFalse(AlertLevel alertLevel);

    /**
     * 查找最近创建的预警记录 - 新增方法
     */
    List<AlertRecord> findTop10ByOrderByCreatedTimeDesc();

    /**
     * 查找指定时间段内的预警记录 - 新增方法
     */
    @Query("SELECT a FROM AlertRecord a WHERE a.createdTime BETWEEN :startTime AND :endTime")
    List<AlertRecord> findByCreatedTimeBetween(@Param("startTime") java.util.Date startTime,
                                               @Param("endTime") java.util.Date endTime);

    /**
     * 统计每个商品的预警数量 - 新增方法
     */
    @Query("SELECT a.productId, COUNT(a) FROM AlertRecord a GROUP BY a.productId")
    List<Object[]> countAlertsByProduct();

    /**
     * 根据商品ID删除预警记录 - 新增方法
     */
    void deleteByProductId(String productId);

    /**
     * 根据商品ID列表删除预警记录 - 新增方法
     */
    void deleteByProductIdIn(List<String> productIds);
}