package com.example.api.controller;

import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/test")
public class TestController {

    @GetMapping("/simple")
    public Map<String, Object> testSimple() {
        Map<String, Object> result = new HashMap<>();
        result.put("code", 200);
        result.put("status", true);
        result.put("msg", "测试成功");
        result.put("data", "Hello World");
        return result;
    }

    @GetMapping("/employee-direct")
    public Map<String, Object> testEmployeeDirect() {
        Map<String, Object> result = new HashMap<>();
        result.put("code", 200);
        result.put("status", true);
        result.put("msg", "直接返回测试");

        // 返回固定测试数据，完全绕过Service和Repository
        Map<String, Object> emp = new HashMap<>();
        emp.put("id", "test-1");
        emp.put("name", "测试员工");
        emp.put("department", "测试部门");

        result.put("data", emp);
        return result;
    }
}