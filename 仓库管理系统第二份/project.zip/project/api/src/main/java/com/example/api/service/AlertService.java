package com.example.api.service;

import java.util.List;
import java.util.Map;

public interface AlertService {

    /**
     * 检查所有商品的库存预警
     */
    void checkInventoryAlerts();

    /**
     * 手动触发预警检查
     */
    void triggerManualCheck();

    /**
     * 获取未处理的预警数量
     */
    long getUnresolvedAlertCount();

    /**
     * 处理预警（标记为已解决）
     */
    boolean resolveAlert(Long alertId, Long resolvedBy);

    /**
     * 获取预警统计信息
     */
    Map<String, Long> getAlertStats();
}