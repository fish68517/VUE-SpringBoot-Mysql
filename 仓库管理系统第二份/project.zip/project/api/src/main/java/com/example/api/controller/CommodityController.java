package com.example.api.controller;

import com.example.api.model.Commodity;
import com.example.api.service.CommodityService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/commodity")
public class CommodityController {

    @Resource
    private CommodityService commodityService;

    /**
     * 创建商品
     */
    @PostMapping
    public ResponseEntity<Commodity> save(@RequestBody Commodity commodity) {
        try {
            Commodity savedCommodity = commodityService.save(commodity);
            return ResponseEntity.ok(savedCommodity);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * 删除商品
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable String id) {
        try {
            if (commodityService.existsById(id)) {
                commodityService.deleteById(id);
                return ResponseEntity.ok().build();
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * 根据ID查询商品 - 修复这里
     */
    @GetMapping("/{id}")
    public ResponseEntity<Commodity> findById(@PathVariable String id) {
        try {
            Commodity commodity = commodityService.findById(id); // 直接获取Commodity对象
            if (commodity != null) {
                return ResponseEntity.ok(commodity);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * 查询所有商品
     */
    @GetMapping
    public ResponseEntity<List<Commodity>> findAll() {
        try {
            List<Commodity> commodities = commodityService.findAll();
            return ResponseEntity.ok(commodities);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * 根据名称模糊搜索商品
     */
    @GetMapping("/search")
    public ResponseEntity<List<Commodity>> findAllByNameLike(@RequestParam String name) {
        try {
            List<Commodity> commodities = commodityService.findAllByNameLike(name);
            return ResponseEntity.ok(commodities);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * 更新商品信息 - 修复这里
     */
    @PutMapping("/{id}")
    public ResponseEntity<Commodity> update(@PathVariable String id, @RequestBody Commodity commodity) {
        try {
            Commodity existingCommodity = commodityService.findById(id); // 直接获取Commodity对象
            if (existingCommodity != null) {
                // 更新商品信息
                existingCommodity.setName(commodity.getName());
                existingCommodity.setCount(commodity.getCount());
                existingCommodity.setPrice(commodity.getPrice());
                existingCommodity.setDescription(commodity.getDescription());

                Commodity updatedCommodity = commodityService.save(existingCommodity);
                return ResponseEntity.ok(updatedCommodity);
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * 根据库存范围查询商品
     */
    @GetMapping("/stock-range")
    public ResponseEntity<List<Commodity>> findByCountBetween(
            @RequestParam Integer minCount,
            @RequestParam Integer maxCount) {
        try {
            List<Commodity> commodities = commodityService.findByCountBetween(minCount, maxCount);
            return ResponseEntity.ok(commodities);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * 根据价格范围查询商品
     */
    @GetMapping("/price-range")
    public ResponseEntity<List<Commodity>> findByPriceBetween(
            @RequestParam Double minPrice,
            @RequestParam Double maxPrice) {
        try {
            List<Commodity> commodities = commodityService.findByPriceBetween(minPrice, maxPrice);
            return ResponseEntity.ok(commodities);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * 查询低库存商品（用于预警）
     */
    @GetMapping("/low-stock")
    public ResponseEntity<List<Commodity>> findLowStock(@RequestParam(defaultValue = "10") Integer threshold) {
        try {
            List<Commodity> commodities = commodityService.findByCountLessThan(threshold);
            return ResponseEntity.ok(commodities);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * 查询高库存商品
     */
    @GetMapping("/over-stock")
    public ResponseEntity<List<Commodity>> findOverStock(@RequestParam(defaultValue = "100") Integer threshold) {
        try {
            List<Commodity> commodities = commodityService.findByCountGreaterThan(threshold);
            return ResponseEntity.ok(commodities);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * 检查商品是否存在
     */
    @GetMapping("/exists/{id}")
    public ResponseEntity<Boolean> existsById(@PathVariable String id) {
        try {
            boolean exists = commodityService.existsById(id);
            return ResponseEntity.ok(exists);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * 获取商品总数
     */
    @GetMapping("/count")
    public ResponseEntity<Long> count() {
        try {
            long count = commodityService.count();
            return ResponseEntity.ok(count);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    /**
     * 批量删除商品
     */
    @DeleteMapping("/batch")
    public ResponseEntity<Void> deleteBatch(@RequestBody List<String> ids) {
        try {
            commodityService.deleteAllById(ids);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }
}