const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// 创建证书存储目录
const certDir = path.join(__dirname, 'cert');
if (!fs.existsSync(certDir)) {
  fs.mkdirSync(certDir);
  console.log('✓ 创建证书目录: cert/');
}

const keyPath = path.join(certDir, 'localhost-key.pem');
const certPath = path.join(certDir, 'localhost-cert.pem');

// 检查是否已存在证书
if (fs.existsSync(keyPath) && fs.existsSync(certPath)) {
  console.log('✓ 证书已存在，无需重新生成');
  console.log(`  私钥: ${keyPath}`);
  console.log(`  证书: ${certPath}`);
  process.exit(0);
}

console.log('开始生成自签名SSL证书...\n');

try {
  // 使用OpenSSL生成私钥和证书
  const opensslCommand = `openssl req -x509 -newkey rsa:2048 -nodes -sha256 -subj "/CN=localhost" -keyout "${keyPath}" -out "${certPath}" -days 365`;
  
  console.log('执行命令生成证书...');
  execSync(opensslCommand, { stdio: 'inherit' });
  
  console.log('\n✓ SSL证书生成成功！');
  console.log(`  私钥文件: ${keyPath}`);
  console.log(`  证书文件: ${certPath}`);
  console.log('\n提示: 首次访问时浏览器会提示不安全，这是正常的。');
  console.log('      点击"高级"然后"继续访问"即可。\n');
  
} catch (error) {
  console.error('\n✗ 证书生成失败！');
  console.error('\n可能的原因：');
  console.error('1. 系统未安装OpenSSL');
  console.error('2. OpenSSL不在系统PATH中\n');
  console.error('解决方案：');
  console.error('Windows用户：');
  console.error('  - 方法1: 使用Git Bash执行此脚本（推荐）');
  console.error('  - 方法2: 下载并安装OpenSSL for Windows');
  console.error('  - 方法3: 使用下面的PowerShell命令手动生成\n');
  console.error('macOS/Linux用户：');
  console.error('  - 使用包管理器安装OpenSSL (brew install openssl / apt install openssl)\n');
  
  process.exit(1);
}
