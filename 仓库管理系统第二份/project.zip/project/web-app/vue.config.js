const fs = require('fs');
const path = require('path');

// 证书文件路径
const certDir = path.join(__dirname, 'cert');
const keyPath = path.join(certDir, 'localhost-key.pem');
const certPath = path.join(certDir, 'localhost-cert.pem');

// 检查证书是否存在
const hasCertificates = fs.existsSync(keyPath) && fs.existsSync(certPath);

if (!hasCertificates) {
  console.warn('\n⚠️  警告: 未找到SSL证书文件');
  console.warn('请先运行以下命令生成证书:');
  console.warn('  npm run generate-cert');
  console.warn('或手动运行:');
  console.warn('  node generate-cert.js');
  console.warn('  (Windows可使用: powershell -ExecutionPolicy Bypass -File generate-cert.ps1)\n');
}

module.exports = {
  devServer: {
    port: 8080,
    https: hasCertificates ? {
      key: fs.readFileSync(keyPath),
      cert: fs.readFileSync(certPath),
    } : false,
    // 启用热重载
    hot: true,
    // 自动打开浏览器
    open: false,
    // 禁用主机检查（允许所有主机访问）
    disableHostCheck: true,
    // 代理配置 - 将/api请求代理到后端服务器
    proxy: {
      '/api': {
        target: 'http://localhost:8088',  // 后端HTTP服务地址
        changeOrigin: true,  // 允许跨域
        ws: true,  // 支持websocket
        secure: false,  // 如果是HTTPS接口，需要配置这个参数
        pathRewrite: {
          // '^/api': '/api'  // 保持/api前缀
        },
        // 日志输出
        onProxyReq: function(proxyReq, req, res) {
          console.log('🔄 代理请求:', req.method, req.url, '-> http://localhost:8088' + req.url);
        },
        onProxyRes: function(proxyRes, req, res) {
          console.log('✅ 代理响应:', proxyRes.statusCode, req.url);
        },
        onError: function(err, req, res) {
          console.error('❌ 代理错误:', err.message);
        }
      }
    }
  },
  // 生产环境配置
  productionSourceMap: false,
  // 公共路径
  publicPath: '/',
  // 输出目录
  outputDir: 'dist',
  // 静态资源目录
  assetsDir: 'static'
};
