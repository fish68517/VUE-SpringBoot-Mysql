import request from "axios"
import { message } from 'ant-design-vue'
import router from '../router/index'

// 使用相对路径 - 通过前端代理转发到后端
// 开发环境: /api -> 代理到 http://localhost:8088/api
// 生产环境: /api -> 同域名下的 /api
const getBaseURL = () => {
    // 如果有环境变量配置，使用环境变量
    if (process.env.VUE_APP_API_BASE_URL) {
        return process.env.VUE_APP_API_BASE_URL;
    }
    
    // 使用相对路径，利用vue.config.js中的proxy代理
    // 这样HTTPS前端可以安全地访问HTTP后端
    return '/api';
};

// 创建axios实例
const service = request.create({
    baseURL: getBaseURL(),
    timeout: 50000
});

console.log('🌐 API Base URL:', getBaseURL());
console.log('📍 当前访问地址:', window.location.href);

// 🎯 新增：请求拦截器 - 自动添加token到请求头
service.interceptors.request.use(
    config => {
        // 从localStorage获取token
        const token = localStorage.getItem("token")
        console.log('🔐 请求拦截器 - 获取到的Token:', token)  // 调试日志
        console.log('🔐 请求URL:', config.url)  // 调试日志
        
        if (token) {
            config.headers['Authorization'] = token
            console.log('✅ 已添加Authorization头:', config.headers['Authorization'])  // 调试日志
            console.log('✅ 完整请求头:', config.headers)  // 调试日志
        } else {
            console.warn('❌ 未找到token，请求将不带认证信息')
        }
        return config
    },
    error => {
        return Promise.reject(error)
    }
)

// 响应拦截器
service.interceptors.response.use(
    response => {
        const res = response.data;
        console.log('📡 响应数据:', res)  // 调试日志
        
        // 判断response状态
        if (!res.status && res.msg) {
            message.error('请求错误: ' + res.msg)
        }
        
        if (res.code === 401) {
            message.error('请先登录')
            // 清除无效token
            localStorage.removeItem("token")
            localStorage.removeItem("user")
            router.push("/login")
        }
        
        if (res.code === 403) {
            message.error('没有访问权限')
            router.push("/403")
        }
        
        return res
    },
    error => {
        console.error('请求错误:', error)
        
        if (error.response) {
            const status = error.response.status
            // 修复：移除可选链操作符
            const messageText = (error.response.data && error.response.data.msg) || '请求失败'
            
            console.log('❌ 错误状态码:', status)  // 调试日志
            console.log('❌ 错误响应:', error.response)  // 调试日志
            
            if (status === 401) {
                message.error('请先登录')
                // 清除无效token
                localStorage.removeItem("token")
                localStorage.removeItem("user")
                router.push('/login')
            } else if (status === 403) {
                message.error('没有访问权限')
                router.push('/403')
            } else if (status === 500) {
                message.error('服务器内部错误')
            } else {
                message.error(messageText)
            }
        } else {
            message.error('网络错误，请检查网络连接')
        }
        
        return Promise.reject(error)
    }
)

console.log("执行request.js - 已配置token拦截器")

export default service