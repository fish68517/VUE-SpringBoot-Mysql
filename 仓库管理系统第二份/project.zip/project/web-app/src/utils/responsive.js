/**
 * 响应式工具类 - 检测设备类型和屏幕尺寸
 */

// 断点定义（与Ant Design保持一致）
export const BREAKPOINTS = {
  xs: 480,   // 手机
  sm: 576,   // 平板竖屏
  md: 768,   // 平板横屏
  lg: 992,   // 桌面
  xl: 1200,  // 大桌面
  xxl: 1600  // 超大桌面
}

/**
 * 检测是否为移动设备
 */
export function isMobile() {
  const width = window.innerWidth
  return width < BREAKPOINTS.md
}

/**
 * 检测是否为平板设备
 */
export function isTablet() {
  const width = window.innerWidth
  return width >= BREAKPOINTS.md && width < BREAKPOINTS.lg
}

/**
 * 检测是否为桌面设备
 */
export function isDesktop() {
  const width = window.innerWidth
  return width >= BREAKPOINTS.lg
}

/**
 * 获取当前设备类型
 */
export function getDeviceType() {
  if (isMobile()) return 'mobile'
  if (isTablet()) return 'tablet'
  return 'desktop'
}

/**
 * 根据屏幕宽度获取断点
 */
export function getBreakpoint() {
  const width = window.innerWidth
  if (width < BREAKPOINTS.xs) return 'xs'
  if (width < BREAKPOINTS.sm) return 'sm'
  if (width < BREAKPOINTS.md) return 'md'
  if (width < BREAKPOINTS.lg) return 'lg'
  if (width < BREAKPOINTS.xl) return 'xl'
  return 'xxl'
}

/**
 * 响应式监听器
 */
export class ResponsiveListener {
  constructor(callback) {
    this.callback = callback
    this.handleResize = this.handleResize.bind(this)
  }

  handleResize() {
    if (this.callback) {
      this.callback({
        width: window.innerWidth,
        height: window.innerHeight,
        isMobile: isMobile(),
        isTablet: isTablet(),
        isDesktop: isDesktop(),
        deviceType: getDeviceType(),
        breakpoint: getBreakpoint()
      })
    }
  }

  start() {
    window.addEventListener('resize', this.handleResize)
    // 立即执行一次
    this.handleResize()
  }

  stop() {
    window.removeEventListener('resize', this.handleResize)
  }
}

/**
 * Vue混入 - 在组件中使用
 */
export const responsiveMixin = {
  data() {
    return {
      $responsive: {
        isMobile: false,
        isTablet: false,
        isDesktop: true,
        deviceType: 'desktop',
        breakpoint: 'lg',
        width: window.innerWidth,
        height: window.innerHeight
      }
    }
  },
  created() {
    this._responsiveListener = new ResponsiveListener((data) => {
      this.$responsive = data
    })
  },
  mounted() {
    this._responsiveListener.start()
  },
  beforeDestroy() {
    if (this._responsiveListener) {
      this._responsiveListener.stop()
    }
  }
}
