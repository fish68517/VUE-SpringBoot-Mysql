import service from "../utils/request";

/**
 * 获取所有商品
 */
export function FindAllCommodity() {
    console.log("执行FindAllCommodity");
    return service({
        url: '/commodity',
        method: 'get'
    })
}

/**
 * 根据名称搜索商品
 */
export function SearchCommodity(name) {
    return service({
        url: '/commodity/search',
        method: 'get',
        params: { name: name }
    })
}

/**
 * 根据ID获取商品详情
 */
export function GetCommodityById(id) {
    return service({
        url: `/commodity/${id}`,
        method: 'get'
    })
}

/**
 * 创建新商品
 */
export function SaveCommodity(data) {
    return service({
        url: '/commodity',
        method: 'post',
        data: data
    })
}

/**
 * 更新商品信息
 */
export function UpdateCommodity(id, data) {
    return service({
        url: `/commodity/${id}`,
        method: 'put',
        data: data
    })
}

/**
 * 删除商品
 */
export function DeleteCommodityById(id) {
    return service({
        url: `/commodity/${id}`,
        method: 'delete'
    })
}

/**
 * 根据库存范围查询商品
 */
export function FindByStockRange(minCount, maxCount) {
    return service({
        url: '/commodity/stock-range',
        method: 'get',
        params: { 
            minCount: minCount,
            maxCount: maxCount
        }
    })
}

/**
 * 根据价格范围查询商品
 */
export function FindByPriceRange(minPrice, maxPrice) {
    return service({
        url: '/commodity/price-range',
        method: 'get',
        params: { 
            minPrice: minPrice,
            maxPrice: maxPrice
        }
    })
}

/**
 * 查询低库存商品（库存预警）
 */
export function FindLowStock(threshold = 10) {
    return service({
        url: '/commodity/low-stock',
        method: 'get',
        params: { threshold: threshold }
    })
}

/**
 * 查询高库存商品（库存预警）
 */
export function FindOverStock(threshold = 100) {
    return service({
        url: '/commodity/over-stock',
        method: 'get',
        params: { threshold: threshold }
    })
}

/**
 * 检查商品是否存在
 */
export function CheckCommodityExists(id) {
    return service({
        url: `/commodity/exists/${id}`,
        method: 'get'
    })
}

/**
 * 获取商品总数
 */
export function GetCommodityCount() {
    return service({
        url: '/commodity/count',
        method: 'get'
    })
}

/**
 * 批量删除商品
 */
export function BatchDeleteCommodity(ids) {
    return service({
        url: '/commodity/batch',
        method: 'delete',
        data: ids
    })
}

/**
 * 根据名称精确查找商品
 */
export function FindCommodityByName(name) {
    return service({
        url: '/commodity/find-by-name',
        method: 'get',
        params: { name: name }
    })
}

/**
 * 根据商品名称包含关键词查找
 */
export function FindCommodityByNameContaining(name) {
    return service({
        url: '/commodity/find-by-name-containing',
        method: 'get',
        params: { name: name }
    })
}

/**
 * 根据库存排序（升序）
 */
export function FindAllOrderByCountAsc() {
    return service({
        url: '/commodity/order-by-count-asc',
        method: 'get'
    })
}

/**
 * 根据库存排序（降序）
 */
export function FindAllOrderByCountDesc() {
    return service({
        url: '/commodity/order-by-count-desc',
        method: 'get'
    })
}

/**
 * 根据价格排序（升序）
 */
export function FindAllOrderByPriceAsc() {
    return service({
        url: '/commodity/order-by-price-asc',
        method: 'get'
    })
}

/**
 * 根据价格排序（降序）
 */
export function FindAllOrderByPriceDesc() {
    return service({
        url: '/commodity/order-by-price-desc',
        method: 'get'
    })
}

/**
 * 获取有库存的商品
 */
export function FindInStockCommodities() {
    return service({
        url: '/commodity/in-stock',
        method: 'get'
    })
}

/**
 * 获取无库存的商品
 */
export function FindOutOfStockCommodities() {
    return service({
        url: '/commodity/out-of-stock',
        method: 'get'
    })
}