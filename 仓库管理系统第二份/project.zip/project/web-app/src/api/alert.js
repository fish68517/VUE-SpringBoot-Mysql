import service from "../utils/request";

// 获取活跃预警列表
export function GetActiveAlerts() {
    return service({
        url: '/alerts/active',
        method: 'get'
    })
}

// 获取预警统计数据
export function GetAlertStats() {
    return service({
        url: '/alerts/stats',
        method: 'get'
    })
}

// 获取高优先级预警
export function GetHighPriorityAlerts() {
    return service({
        url: '/alerts/high-priority',
        method: 'get'
    })
}

// 立即检查预警
export function CheckAlertsNow() {
    return service({
        url: '/alerts/check-now',
        method: 'post'
    })
}

// 标记预警为已处理
export function ResolveAlert(alertId, resolvedBy) {
    return service({
        url: `/alerts/${alertId}/resolve`,
        method: 'post',
        data: {
            resolvedBy: resolvedBy
        }
    })
}