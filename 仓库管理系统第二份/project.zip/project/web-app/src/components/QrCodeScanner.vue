<template>
  <div class="qr-scanner-container">
    <div class="mobile-scanner">
      <div class="mobile-header">
        <p class="browser-tip">📱 实时扫码识别系统</p>
      </div>
      
      <!-- 主要功能区 -->
      <div class="qq-browser-features">
        <!-- 实时扫码功能 -->
        <div class="feature-card">
          <div class="feature-icon">📷</div>
          <div class="feature-content">
            <h4>实时扫码识别</h4>
            <p>打开摄像头实时检测二维码，自动识别并查询</p>
            <a-button 
              @click="startRealTimeScanner" 
              type="primary" 
              size="large"
              block
              class="feature-btn"
            >
              <a-icon type="scan" />
              开始实时扫码
            </a-button>
          </div>
        </div>

        <!-- 手动输入 -->
        <div class="feature-card">
          <div class="feature-icon">⌨️</div>
          <div class="feature-content">
            <h4>手动输入条码</h4>
            <p>直接输入商品条码，快速完成操作</p>
            <a-button 
              @click="switchToInput" 
              size="large"
              block
              class="feature-btn"
            >
              <a-icon type="edit" />
              手动输入条码
            </a-button>
          </div>
        </div>
     </div>

      <!-- 手动输入区域 -->
      <div v-if="showInput" class="input-section">
        <div class="input-header">
          <h4>⌨️ 手动输入商品条码</h4>
          <a-button @click="showInput = false" size="small" type="link">关闭</a-button>
        </div>
        <a-input
          v-model="manualCode"
          placeholder="请输入13位商品条码，如：6941234567890"
          size="large"
          @keyup.enter="handleManualInput"
          clearable
          ref="manualInput"
        >
          <template slot="prefix">
            <a-icon type="barcode" />
          </template>
        </a-input>
        <a-button 
          @click="handleManualInput" 
          type="primary" 
          size="large"
          :disabled="!manualCode"
          block
          style="margin-top: 12px;"
        >
          确认输入
        </a-button>
        <div class="input-tips">
          <p>💡 支持格式：13位标准条码 | 自定义编码 | 任意文本</p>
        </div>
      </div>

      <!-- 实时扫码模态框 -->
      <a-modal
        v-model="scannerModalVisible"
        title="实时扫码识别"
        :footer="null"
        :maskClosable="false"
        :width="isMobileDevice ? '95%' : 800"
        @cancel="stopScanner"
        :bodyStyle="{padding: isMobileDevice ? '16px' : '24px'}"
        :centered="true"
        wrapClassName="scanner-modal-wrap"
      >
        <div class="scanner-modal-content">
          <!-- 视频预览区域 -->
          <div class="video-container">
            <video ref="video" autoplay playsinline class="scanner-video"></video>
            <canvas ref="canvas" class="scanner-canvas"></canvas>
            
            <!-- 扫码状态显示 -->
            <div class="scan-status" :class="{active: isScanning}">
              <div v-if="isScanning && !lastScannedCode">
                <a-icon type="loading" spin />
                <span>正在检测二维码...</span>
              </div>
              <div v-if="lastScannedCode" class="scan-success">
                <a-icon type="check-circle" theme="filled" />
                <span>识别成功: {{ lastScannedCode }}</span>
              </div>
            </div>
          </div>
          
          <!-- 实时识别内容显示 -->
          <div class="scan-info">
            <h4>📋 扫码信息</h4>
            <div v-if="lastScannedCode" class="scanned-result">
              <p><strong>识别内容:</strong> {{ lastScannedCode }}</p>
              <p><strong>识别时间:</strong> {{ scanTime }}</p>
            </div>
            <div v-else class="waiting-scan">
              <p>等待扫描二维码...</p>
            </div>
          </div>
          
          <!-- 操作按钮 -->
          <div class="scanner-actions">
            <a-button @click="stopScanner" size="large">
              <a-icon type="close" />
              关闭扫码
            </a-button>
            <a-button 
              v-if="lastScannedCode" 
              @click="manualQuery" 
              type="primary" 
              size="large"
            >
              <a-icon type="search" />
              手动查询
            </a-button>
          </div>
        </div>
      </a-modal>

      <!-- 结果弹窗 -->
      <a-modal
        v-if="showResultModal"
        :visible="showResultModal"
        :title="'查询结果'"
        @ok="handleResultOk"
        @cancel="handleResultCancel"
        :maskClosable="false"
        width="95%"
      >
        <div v-if="productInfo" class="product-details">
          <p><strong>商品名称:</strong> {{ productInfo.name }}</p>
          <p><strong>商品条码:</strong> {{ productInfo.barcode }}</p>
          <p><strong>商品分类:</strong> {{ productInfo.category }}</p>
          <p><strong>当前库存:</strong> {{ productInfo.stock }}</p>
          <p><strong>安全库存:</strong> {{ productInfo.safeStock }}</p>
          
          <!-- 显示二维码中的额外信息 -->
          <div v-if="productInfo.qrData" class="qr-data-info">
            <a-divider>二维码信息</a-divider>
            <p><strong>操作类型:</strong>
              <a-tag :color="productInfo.qrData.type === 'IN' ? 'green' : 'orange'">
                {{ productInfo.qrData.type === 'IN' ? '入库' : '出库' }}
              </a-tag>
            </p>
            <p><strong>商品ID:</strong> {{ productInfo.qrData.commodityId }}</p>
            <p><strong>操作数量:</strong> {{ productInfo.qrData.quantity }}</p>
            <p v-if="productInfo.qrData.remark"><strong>备注信息:</strong> {{ productInfo.qrData.remark }}</p>
            <p><strong>生成时间:</strong> {{ new Date(productInfo.qrData.timestamp).toLocaleString() }}</p>
          </div>
          
          <!-- 数量输入 -->
          <div v-if="showQuantityInput" class="quantity-input">
            <a-divider>操作数量</a-divider>
            <a-input-number
              v-model="quantity"
              :min="1"
              :max="maxQuantity"
              style="width: 100%"
              size="large"
              placeholder="请输入操作数量"
            />
            <p style="margin-top: 8px; color: #666;">
              当前操作: {{ getOperationText() }} | 最大数量: {{ maxQuantity }}
            </p>
          </div>
        </div>
      </a-modal>
    </div>
  </div>
</template>

<script>
import { GetCommodityById } from '@/api/commodity'

export default {
  name: 'QrCodeScanner',
  props: {
    title: {
      type: String,
      default: '扫码操作'
    },
    showCancel: {
      type: Boolean,
      default: true
    },
    showConfirm: {
      type: Boolean,
      default: true
    },
    confirmText: {
      type: String,
      default: '确认操作'
    },
    showQuantityInput: {
      type: Boolean,
      default: true
    },
    operationType: {
      type: String,
      default: 'inbound'
    },
    warehouseId: {
      type: [String, Number],
      default: null
    }
  },
  data() {
    return {
      // 基本属性
      showInput: false,
      showResultModal: false,
      
      // 扫码相关
      scannedResult: null,
      manualCode: '',
      confirmLoading: false,
      productInfo: null,
      quantity: 1,
      maxQuantity: 9999,
      qrCodeType: null, // 存储二维码中的操作类型（IN/OUT），优先级高于 prop
      
      // 实时扫码相关
      scannerModalVisible: false,
      isScanning: false,
      lastScannedCode: '',
      scanTime: '',
      videoStream: null,
      animationFrameId: null,
      autoQueryEnabled: true,
      videoReady: false,
      videoStyleApplied: false,
     canvasInitialized: false
    }
  },
  computed: {
    isMobileDevice() {
      return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || window.innerWidth <= 768
    }
  },
  mounted() {
    // 将Vue实例暴露给全局，以便在HTML中调用
    window.vueInstance = this
  },
  beforeDestroy() {
    // 清理全局引用
    if (window.vueInstance === this) {
      window.vueInstance = null
    }
    // 停止扫码
    this.stopScanner()
  },
  methods: {
    // 🎯 启动实时扫码
    async startRealTimeScanner() {
      try {
        this.scannerModalVisible = true
        this.$message.loading('正在启动摄像头...', 0)
        
        // 先尝试简单配置
        let stream = null
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            video: {
              facingMode: 'environment',
              width: { ideal: 1280 },
              height: { ideal: 720 }
            }
          })
        } catch (err) {
          // 降级：使用最简单的配置
          console.log('尝试降级配置...')
          stream = await navigator.mediaDevices.getUserMedia({
            video: true
          })
        }
        
        this.$message.destroy()
        this.$message.success('摄像头启动成功!')
        
        // 设置视频流
        this.videoStream = stream
        const video = this.$refs.video
        this.videoReady = false
        this.videoStyleApplied = false
        
        video.srcObject = stream
        
        // 等待视频加载
        await new Promise((resolve, reject) => {
          video.onloadedmetadata = () => {
            console.log('📹 视频metadata加载完成')
            video.play().then(() => {
              console.log('▶️ 视频开始播放')
              console.log('🔍 videoStyleApplied状态:', this.videoStyleApplied)
              // 只设置一次样式
              if (!this.videoStyleApplied) {
                console.log('✅ 准备应用视频样式')
                this.forceVideoStyle(video)
                this.videoStyleApplied = true
                console.log('✅ 视频样式已应用，标记为true')
              } else {
                console.log('⚠️ 样式已应用过，跳过')
              }
              this.videoReady = true
              resolve()
            }).catch(reject)
          }
          // 超时保护
          setTimeout(() => reject(new Error('视频加载超时')), 5000)
        })
        
        // 开始扫码
        this.isScanning = true
        this.scanLoop()
        
      } catch (error) {
        this.$message.destroy()
        console.error('启动摄像头失败:', error)
        
        if (error.name === 'NotAllowedError') {
          this.$message.error('摄像头权限被拒绝，请在浏览器设置中允许访问摄像头')
        } else if (error.name === 'NotFoundError') {
          this.$message.error('未检测到摄像头设备')
        } else if (error.name === 'NotReadableError') {
          this.$message.error('摄像头被其他应用占用，请关闭其他使用摄像头的应用后重试')
        } else {
          this.$message.error('无法启动摄像头: ' + error.message)
        }
        
        this.scannerModalVisible = false
      }
    },
    
    // 🎯 扫码循环
    scanLoop() {
      if (!this.isScanning || !this.$refs.video || !this.$refs.canvas) {
        return
      }
      
      const video = this.$refs.video
      const canvas = this.$refs.canvas
      const ctx = canvas.getContext('2d')
      const container = canvas.parentElement
      
      // 设置canvas尺寸为固定值
      if (video.readyState === video.HAVE_ENOUGH_DATA) {
        // 只初始化一次canvas尺寸
        if (!this.canvasInitialized) {
          // 根据设备类型设置不同的固定尺寸
          let fixedWidth, fixedHeight
          
          if (this.isMobileDevice) {
            // 移动设备：获取容器实际宽度，高度使用CSS定义的值
            const containerRect = container.getBoundingClientRect()
            fixedWidth = containerRect.width
            if (window.innerWidth <= 480) {
              fixedHeight = 250
            } else {
              fixedHeight = 300
            }
          } else {
            // 桌面设备
            fixedWidth = 752
            fixedHeight = 400
          }
          
          console.log('📐 初始化Canvas尺寸:', fixedWidth, 'x', fixedHeight, '(设备类型:', this.isMobileDevice ? '移动' : '桌面', ')')
          canvas.width = fixedWidth
          canvas.height = fixedHeight
          this.canvasInitialized = true
        }
        
        // 检查视频尺寸是否有效
        if (!video.videoWidth || !video.videoHeight || video.videoWidth === 0 || video.videoHeight === 0) {
          this.animationFrameId = requestAnimationFrame(() => this.scanLoop())
          return
        }
        
        // 创建临时canvas处理完整视频帧
        const tempCanvas = document.createElement('canvas')
        tempCanvas.width = video.videoWidth
        tempCanvas.height = video.videoHeight
        const tempCtx = tempCanvas.getContext('2d')
        tempCtx.drawImage(video, 0, 0, tempCanvas.width, tempCanvas.height)
        
        // 获取图像数据
        const imageData = tempCtx.getImageData(0, 0, tempCanvas.width, tempCanvas.height)
        
        // 使用jsQR识别二维码
        const code = window.jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'dontInvert'
        })
        
        if (code) {
          // 检测到二维码
          this.handleQRCodeDetected(code, ctx, video, canvas, container)
        } else {
          // 清除之前的标记
          ctx.clearRect(0, 0, canvas.width, canvas.height)
        }
      }
      
      // 继续扫描
      this.animationFrameId = requestAnimationFrame(() => this.scanLoop())
    },
    
    // 🎯 处理检测到的二维码
    handleQRCodeDetected(code, ctx, video, canvas, container) {
      const currentCode = code.data
      
      // 绘制二维码位置标记
      this.drawQRCodeLocation(code.location, ctx, video, canvas, container)
      
      // 如果是新的二维码
      if (currentCode !== this.lastScannedCode) {
        this.lastScannedCode = currentCode
        this.scanTime = new Date().toLocaleString()
        
        // 播放提示音（如果需要）
        this.playBeep()
        
        // 自动查询
        if (this.autoQueryEnabled) {
          this.$message.success('识别成功: ' + currentCode)
          setTimeout(() => {
            this.autoQuery(currentCode)
          }, 500)
        }
      }
    },
    
    // 🎯 绘制二维码位置
    drawQRCodeLocation(location, ctx, video, canvas, container) {
      // 获取video的实际显示尺寸
      const videoRect = video.getBoundingClientRect()
      const containerRect = container.getBoundingClientRect()
      
      // 计算video在容器中的偏移量
      const offsetX = (containerRect.width - videoRect.width) / 2
      const offsetY = (containerRect.height - videoRect.height) / 2
      
      // 计算从原始视频到显示尺寸的缩放比例
      const scaleX = videoRect.width / video.videoWidth
      const scaleY = videoRect.height / video.videoHeight
      
      // 绘制边框
      ctx.strokeStyle = '#00ff00'
      ctx.lineWidth = 3
      ctx.beginPath()
      ctx.moveTo(location.topLeftCorner.x * scaleX + offsetX, location.topLeftCorner.y * scaleY + offsetY)
      ctx.lineTo(location.topRightCorner.x * scaleX + offsetX, location.topRightCorner.y * scaleY + offsetY)
      ctx.lineTo(location.bottomRightCorner.x * scaleX + offsetX, location.bottomRightCorner.y * scaleY + offsetY)
      ctx.lineTo(location.bottomLeftCorner.x * scaleX + offsetX, location.bottomLeftCorner.y * scaleY + offsetY)
      ctx.lineTo(location.topLeftCorner.x * scaleX + offsetX, location.topLeftCorner.y * scaleY + offsetY)
      ctx.stroke()
      
      // 绘制角点
      ctx.fillStyle = '#00ff00'
      const corners = [
        location.topLeftCorner,
        location.topRightCorner,
        location.bottomRightCorner,
        location.bottomLeftCorner
      ]
      corners.forEach(corner => {
        ctx.beginPath()
        ctx.arc(corner.x * scaleX + offsetX, corner.y * scaleY + offsetY, 5, 0, 2 * Math.PI)
        ctx.fill()
      })
    },
    
    // 🎯 播放提示音
    playBeep() {
      try {
        const audioContext = new (window.AudioContext || window.webkitAudioContext)()
        const oscillator = audioContext.createOscillator()
        const gainNode = audioContext.createGain()
        
        oscillator.connect(gainNode)
        gainNode.connect(audioContext.destination)
        
        oscillator.frequency.value = 800
        oscillator.type = 'sine'
        
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime)
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.2)
        
        oscillator.start(audioContext.currentTime)
        oscillator.stop(audioContext.currentTime + 0.2)
      } catch (error) {
        console.log('播放提示音失败:', error)
      }
    },
    
    // 🎯 自动查询
    async autoQuery(code) {
      console.log('自动查询:', code)
      this.scannedResult = code
      
      // 尝试解析JSON格式的二维码数据
      try {
        const qrData = JSON.parse(code)
        console.log('解析到JSON格式的二维码数据:', qrData)
        
        // 如果是JSON格式，直接使用其中的数据
        if (qrData.type && qrData.commodityId && qrData.quantity) {
          await this.generateProductInfoFromQR(qrData)
        } else {
          // JSON格式但不完整，回退到普通条码处理
          this.generateProductInfo(code)
        }
      } catch (error) {
        // 不是JSON格式，使用普通条码处理
        console.log('不是JSON格式，使用普通条码处理')
        this.generateProductInfo(code)
      }
      
      // 停止扫码
      this.stopScanner()
      
      // 显示查询结果
      this.showResultModal = true
      this.$emit('scanned', code)
    },
    
    // 🎯 手动查询
    manualQuery() {
      if (this.lastScannedCode) {
        this.autoQuery(this.lastScannedCode)
      }
    },
    
    // 🎯 强制设置视频样式（只执行一次）
    forceVideoStyle(video) {
      console.log('🎨 forceVideoStyle被调用')
      console.log('   - video元素存在:', !!video)
      console.log('   - videoStyleApplied:', this.videoStyleApplied)
      
      if (!video) {
        console.log('❌ 退出：video元素不存在')
        return
      }
      
      if (this.videoStyleApplied) {
        console.log('❌ 退出：样式已应用过')
        return
      }
      
      console.log('🎨 正在应用视频样式...')
      video.style.cssText = `
        position: absolute !important;
        top: 0 !important;
        left: 0 !important;
        width: 100% !important;
        height: 100% !important;
        object-fit: cover !important;
        display: block !important;
      `
      console.log('✅ 视频样式应用完成')
      console.log('   - 当前video.style.width:', video.style.width)
      console.log('   - 当前video.style.height:', video.style.height)
    },
    
    // 🎯 停止扫码
    stopScanner() {
      console.log('🛑 停止扫码，重置所有状态')
      this.isScanning = false
      this.videoReady = false
      this.videoStyleApplied = false
      this.canvasInitialized = false
      console.log('   - videoStyleApplied已重置为false')
      console.log('   - canvasInitialized已重置为false')
      
      // 停止动画帧
      if (this.animationFrameId) {
        cancelAnimationFrame(this.animationFrameId)
        this.animationFrameId = null
      }
      
      // 停止视频流
      if (this.videoStream) {
        this.videoStream.getTracks().forEach(track => track.stop())
        this.videoStream = null
      }
      
      // 清空视频元素
      if (this.$refs.video) {
        this.$refs.video.srcObject = null
      }
      
      // 关闭模态框
      this.scannerModalVisible = false
    },
    
    // 其他方法保持不变...
    switchToInput() {
      this.showInput = true
      this.$nextTick(() => {
        if (this.$refs.manualInput) {
          this.$refs.manualInput.focus()
        }
      })
    },

    handleManualInput() {
      const inputCode = this.manualCode.trim()
      if (inputCode) {
        this.handleScanResult(inputCode)
        this.manualCode = ''
        this.showInput = false
      }
    },

    generateProductInfo(barcode) {
      const productTemplates = {
        '6941234567890': { name: '笔记本电脑', category: '电子产品' },
        '6923456789012': { name: '智能手机', category: '电子产品' },
        '6934567890123': { name: '无线耳机', category: '音频设备' },
        '6901234567897': { name: '瓶装饮料', category: '食品饮料' },
        '6912345678901': { name: '包装食品', category: '休闲食品' }
      }
      
      const template = productTemplates[barcode] || {
        name: `商品-${barcode}`,
        category: '普通商品'
      }
      
      this.productInfo = {
        id: Math.floor(Math.random() * 1000) + 1,
        name: template.name,
        stock: Math.floor(Math.random() * 100) + 10,
        safeStock: 20,
        barcode: barcode,
        category: template.category
      }
      
      if (this.operationType === 'outbound') {
        this.maxQuantity = this.productInfo.stock
        this.quantity = Math.min(1, this.maxQuantity)
      } else {
        this.maxQuantity = 999
        this.quantity = 1
      }
    },
    
    // 🎯 从二维码数据生成产品信息（从数据库查询）
    async generateProductInfoFromQR(qrData) {
      console.log('从二维码数据生成产品信息:', qrData)
      
      // 保存二维码中的操作类型（IN/OUT），优先级高于 prop
      this.qrCodeType = qrData.type
      console.log('二维码操作类型:', this.qrCodeType, '(IN=入库, OUT=出库)')
      
      try {
        // 🔥 从数据库查询商品信息
        console.log('📡 正在从数据库查询商品ID:', qrData.commodityId)
        const response = await GetCommodityById(qrData.commodityId)
        console.log('✅ 数据库查询结果:', response)
        
        let commodityData
        if (response && response.data) {
          commodityData = response.data
        } else if (response) {
          commodityData = response
        } else {
          throw new Error('查询结果为空')
        }
        
        // 使用数据库查询到的真实商品信息
        this.productInfo = {
          id: qrData.commodityId,
          name: commodityData.name || `商品-${qrData.commodityId}`,
          stock: commodityData.count || 0,
          safeStock: commodityData.safeStock || 20,
          barcode: qrData.commodityId,
          category: commodityData.type || '普通商品',
          // 保存原始二维码数据
          qrData: qrData
        }
        
        console.log('✅ 使用数据库中的商品信息:', this.productInfo)
        
      } catch (error) {
        console.error('❌ 从数据库查询商品信息失败:', error)
        this.$message.warning('查询商品信息失败，使用默认信息')
        
        // 查询失败时使用默认信息
        this.productInfo = {
          id: qrData.commodityId,
          name: `商品-${qrData.commodityId}`,
          stock: 100,
          safeStock: 20,
          barcode: qrData.commodityId,
          category: '普通商品',
          qrData: qrData
        }
      }
      
      // 设置数量为二维码中的数量
      this.quantity = qrData.quantity
      
      // 根据二维码中的 type 判断操作类型
      const actualOperationType = qrData.type === 'IN' ? 'inbound' : 'outbound'
      
      // 如果是出库操作，限制最大数量为库存数量
      if (actualOperationType === 'outbound') {
        this.maxQuantity = this.productInfo.stock
        this.quantity = Math.min(qrData.quantity, this.maxQuantity)
        console.log('出库操作，最大数量限制为库存:', this.maxQuantity)
      } else {
        this.maxQuantity = 9999
        console.log('入库操作，最大数量:', this.maxQuantity)
      }
      
      console.log('生成的产品信息:', this.productInfo)
    },
    
    handleResultOk() {
      this.confirmLoading = true
      
      // 优先使用二维码中的 type，如果没有则使用 prop 中的 operationType
      let finalOperationType = this.operationType
      
      if (this.qrCodeType) {
        // 二维码中有 type 信息，使用它（IN -> inbound, OUT -> outbound）
        finalOperationType = this.qrCodeType === 'IN' ? 'inbound' : 'outbound'
        console.log('使用二维码中的操作类型:', this.qrCodeType, '-> ', finalOperationType)
      } else {
        console.log('使用 prop 中的操作类型:', finalOperationType)
      }
      
      const operationData = {
        barcode: this.scannedResult,
        productInfo: this.productInfo,
        quantity: this.quantity,
        warehouseId: this.warehouseId,
        operationType: finalOperationType,
        qrCodeType: this.qrCodeType // 传递原始的二维码类型
      }
      
      console.log('发送确认数据:', operationData)
      this.$emit('confirm', operationData)
      
      setTimeout(() => {
        this.showResultModal = false
        this.confirmLoading = false
        this.clearResult()
        this.$message.success(`${this.getOperationText()}操作成功!`)
      }, 1000)
    },
    
    clearResult() {
      this.scannedResult = null
      this.productInfo = null
      this.quantity = 1
      this.qrCodeType = null // 清除二维码类型
      this.showInput = false
    },


    handleScanResult(code) {
      console.log('✅ 识别结果:', code)
      this.scannedResult = code
      this.generateProductInfo(code)
      this.showResultModal = true
      this.$emit('scanned', code)
    },

    getOperationText() {
      const texts = {
        'inbound': '入库',
        'outbound': '出库', 
        'query': '查询'
      }
      return texts[this.operationType] || '操作'
    }
  }
}
</script>

<style scoped>
.qr-scanner-container {
  width: 100%;
  height: 100%;
}

.mobile-scanner {
  padding: 20px;
}

.mobile-header {
  text-align: center;
  margin-bottom: 20px;
}

.browser-tip {
  font-size: 16px;
  font-weight: bold;
  color: #1890ff;
  margin: 0;
}

.qq-browser-features {
  display: flex;
  flex-direction: column;
  gap: 15px;
  margin-bottom: 20px;
}

.feature-card {
  display: flex;
  align-items: center;
  padding: 15px;
  border: 1px solid #d9d9d9;
  border-radius: 8px;
  background: #fafafa;
}

.feature-icon {
  font-size: 24px;
  margin-right: 15px;
}

.feature-content h4 {
  margin: 0 0 5px 0;
  font-size: 16px;
}

.feature-content p {
  margin: 0 0 10px 0;
  color: #666;
  font-size: 14px;
}

.feature-btn {
  margin-top: 5px;
}

.input-section {
  margin-bottom: 20px;
  padding: 15px;
  border: 1px solid #d9d9d9;
  border-radius: 8px;
  background: #f9f9f9;
}

.input-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
}

.input-header h4 {
  margin: 0;
}

.input-tips {
  margin-top: 10px;
}

.input-tips p {
  margin: 0;
  font-size: 12px;
  color: #666;
}

.scanner-modal-content {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.video-container {
  position: relative;
  width: 100%;
  height: 300px;
  background: #000;
  border-radius: 8px;
  overflow: hidden;
}

.scanner-video {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.scanner-canvas {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}

.scan-status {
  position: absolute;
  top: 10px;
  left: 10px;
  background: rgba(0, 0, 0, 0.7);
  color: white;
  padding: 8px 12px;
  border-radius: 4px;
  font-size: 14px;
  display: flex;
  align-items: center;
  gap: 8px;
}

.scan-status.active {
  background: rgba(24, 144, 255, 0.8);
}

.scan-success {
  color: #52c41a;
}

.scan-info h4 {
  margin-bottom: 10px;
}

.scanned-result p {
  margin: 5px 0;
}

.waiting-scan {
  color: #666;
  font-style: italic;
}

.scanner-actions {
  display: flex;
  gap: 10px;
  justify-content: center;
}

.product-details p {
  margin: 8px 0;
}

/* 移动端适配 */
@media (max-width: 768px) {
  .mobile-scanner {
    padding: 10px;
  }
  
  .feature-card {
    flex-direction: column;
    text-align: center;
  }
  
  .feature-icon {
    margin-right: 0;
    margin-bottom: 10px;
  }
  
  .video-container {
    height: 250px;
  }
  
  .scanner-actions {
    flex-direction: column;
  }
}
</style>