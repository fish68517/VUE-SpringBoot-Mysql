<template>
  <div class="mobile-table-wrapper">
    <!-- 桌面端：显示正常表格 -->
    <a-table
      v-if="!isMobile"
      v-bind="$attrs"
      v-on="$listeners"
    >
      <template v-for="(_, slot) of $scopedSlots" v-slot:[slot]="scope">
        <slot :name="slot" v-bind="scope" />
      </template>
    </a-table>
    
    <!-- 移动端：卡片列表 -->
    <div v-else class="mobile-card-list">
      <a-card
        v-for="(item, index) in dataSource"
        :key="index"
        :bordered="true"
        size="small"
        class="mobile-card-item"
      >
        <div class="card-content">
          <div
            v-for="col in visibleColumns"
            :key="col.dataIndex || col.key"
            class="card-row"
          >
            <div class="card-label">{{ col.title }}：</div>
            <div class="card-value">
              <!-- 如果有自定义插槽，使用插槽 -->
              <slot
                v-if="$scopedSlots[col.dataIndex] || $scopedSlots[col.key]"
                :name="col.dataIndex || col.key"
                :text="getColumnValue(item, col)"
                :record="item"
                :index="index"
              />
              <!-- 否则显示原始值 -->
              <span v-else>{{ getColumnValue(item, col) }}</span>
            </div>
          </div>
          
          <!-- 操作列 -->
          <div v-if="$scopedSlots.action" class="card-actions">
            <slot name="action" :record="item" :index="index" />
          </div>
        </div>
      </a-card>
      
      <!-- 移动端分页 -->
      <div v-if="pagination" class="mobile-pagination">
        <a-pagination
          v-bind="typeof pagination === 'object' ? pagination : {}"
          simple
          @change="handlePageChange"
        />
      </div>
    </div>
  </div>
</template>

<script>
import { isMobile } from '@/utils/responsive'

export default {
  name: 'MobileTable',
  inheritAttrs: false,
  props: {
    columns: {
      type: Array,
      default: () => []
    },
    dataSource: {
      type: Array,
      default: () => []
    },
    pagination: {
      type: [Object, Boolean],
      default: false
    }
  },
  data() {
    return {
      isMobile: false
    }
  },
  computed: {
    // 过滤掉不需要在移动端显示的列
    visibleColumns() {
      return this.columns.filter(col => {
        // 操作列单独处理
        if (col.dataIndex === 'action' || col.key === 'action') {
          return false
        }
        // 移动端隐藏的列
        if (col.mobileHidden) {
          return false
        }
        return true
      })
    }
  },
  methods: {
    checkDevice() {
      this.isMobile = isMobile()
    },
    getColumnValue(record, column) {
      const dataIndex = column.dataIndex || column.key
      if (!dataIndex) return ''
      
      // 支持嵌套属性 如 'user.name'
      if (dataIndex.includes('.')) {
        return dataIndex.split('.').reduce((obj, key) => obj?.[key], record)
      }
      
      return record[dataIndex]
    },
    handlePageChange(page, pageSize) {
      this.$emit('change', { current: page, pageSize })
    }
  },
  mounted() {
    this.checkDevice()
    window.addEventListener('resize', this.checkDevice)
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.checkDevice)
  }
}
</script>

<style scoped>
.mobile-table-wrapper {
  width: 100%;
}

/* 移动端卡片列表样式 */
.mobile-card-list {
  width: 100%;
}

.mobile-card-item {
  margin-bottom: 12px;
  border-radius: 8px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
}

.mobile-card-item:last-child {
  margin-bottom: 0;
}

.card-content {
  font-size: 14px;
}

.card-row {
  display: flex;
  padding: 8px 0;
  border-bottom: 1px solid #f0f0f0;
  align-items: flex-start;
}

.card-row:last-child {
  border-bottom: none;
  padding-bottom: 0;
}

.card-label {
  flex-shrink: 0;
  width: 90px;
  font-weight: 500;
  color: rgba(0, 0, 0, 0.65);
}

.card-value {
  flex: 1;
  color: rgba(0, 0, 0, 0.85);
  word-break: break-all;
}

.card-actions {
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px solid #f0f0f0;
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
}

.card-actions >>> .ant-btn {
  flex: 1;
  min-width: 80px;
}

/* 移动端分页 */
.mobile-pagination {
  margin-top: 16px;
  text-align: center;
}

.mobile-pagination >>> .ant-pagination-simple {
  display: inline-flex;
  align-items: center;
}

.mobile-pagination >>> .ant-pagination-simple-pager input {
  margin: 0 8px;
}

/* 桌面端正常显示 */
@media (min-width: 768px) {
  .mobile-card-list {
    display: none;
  }
}
</style>
