<template>
  <div class="ecommerce-analysis">
    <div class="page-header">
      <h1>电子商务分析中心</h1>
      <p>实时监控物流数据和业务指标</p>
    </div>

    <a-row :gutter="20" class="stats-cards">
      <a-col :span="6">
        <a-card class="stats-card">
          <div class="card-content">
            <div class="card-icon" style="background: #1890ff;">
              <a-icon type="shopping-cart" />
            </div>
            <div class="card-info">
              <h3>今日订单</h3>
              <div class="number">1,234</div>
              <div class="trend up">↑ 1.3% 结算日</div>
            </div>
          </div>
        </a-card>
      </a-col>

      <a-col :span="6">
        <a-card class="stats-card">
          <div class="card-content">
            <div class="card-icon" style="background: #52c41a;">
              <a-icon type="car" />
            </div>
            <div class="card-info">
              <h3>在线选择</h3>
              <div class="number">567</div>
              <div class="trend up">↑ 1.6% 线上单</div>
            </div>
          </div>
        </a-card>
      </a-col>

      <a-col :span="6">
        <a-card class="stats-card">
          <div class="card-content">
            <div class="card-icon" style="background: #faad14;">
              <a-icon type="shop" />
            </div>
            <div class="card-info">
              <h3>仓库库存</h3>
              <div class="number">85%</div>
              <div class="trend up">↑ 1.5% 结算日</div>
            </div>
          </div>
        </a-card>
      </a-col>

      <a-col :span="6">
        <a-card class="stats-card">
          <div class="card-content">
            <div class="card-icon" style="background: #f5222d;">
              <a-icon type="clock-circle" />
            </div>
            <div class="card-info">
              <h3>平均时效</h3>
              <div class="number">2.3天</div>
              <div class="trend down">↓ 0.3天 优化</div>
            </div>
          </div>
        </a-card>
      </a-col>
    </a-row>

    <a-row :gutter="20" class="chart-area">
      <a-col :span="12">
        <a-card title="📈 订单趋势分析" class="chart-card">
          <div id="orderTrendChart" class="chart-container"></div>
        </a-card>
      </a-col>
      <a-col :span="12">
        <a-card title="🗺️ 物流地理分布" class="chart-card">
          <div id="geoDistributionChart" class="chart-container"></div>
        </a-card>
      </a-col>
    </a-row>
  </div>
</template>

<script>
import * as echarts from 'echarts';

export default {
  name: 'EcommerceAnalysis',
  mounted() {
    this.$nextTick(() => {
      this.initOrderTrendChart();
      this.initGeoDistributionChart();
    });
  },
  methods: {
    initOrderTrendChart() {
      const chartDom = document.getElementById('orderTrendChart');
      if (!chartDom) return;
      
      const chart = echarts.init(chartDom);
      const option = {
        tooltip: {
          trigger: 'axis',
          formatter: function(params) {
            let result = params[0].axisValue + '<br/>';
            params.forEach(param => {
              result += `${param.seriesName}: ${param.value} 单<br/>`;
            });
            return result;
          }
        },
        legend: {
          data: ['订单量', '配送量', '退货量'],
          top: '5%'
        },
        grid: {
          left: '3%',
          right: '4%',
          bottom: '3%',
          top: '15%',
          containLabel: true
        },
        xAxis: {
          type: 'category',
          data: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'],
          axisLine: {
            lineStyle: {
              color: '#666'
            }
          }
        },
        yAxis: {
          type: 'value',
          name: '订单量（单）',
          axisLine: {
            lineStyle: {
              color: '#666'
            }
          },
          splitLine: {
            lineStyle: {
              color: '#f0f0f0'
            }
          }
        },
        series: [
          {
            name: '订单量',
            type: 'line',
            data: [820, 932, 901, 934, 1290, 1330, 1320, 1010, 1100, 1230, 1350, 1400],
            smooth: true,
            lineStyle: {
              width: 3,
              color: '#1890ff'
            },
            itemStyle: {
              color: '#1890ff'
            },
            areaStyle: {
              color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                { offset: 0, color: 'rgba(24, 144, 255, 0.6)' },
                { offset: 1, color: 'rgba(24, 144, 255, 0.1)' }
              ])
            }
          },
          {
            name: '配送量',
            type: 'line',
            data: [780, 890, 860, 900, 1250, 1300, 1280, 980, 1050, 1180, 1300, 1350],
            smooth: true,
            lineStyle: {
              width: 2,
              color: '#52c41a'
            },
            itemStyle: {
              color: '#52c41a'
            }
          },
          {
            name: '退货量',
            type: 'line',
            data: [40, 42, 41, 34, 40, 30, 40, 30, 50, 50, 50, 50],
            smooth: true,
            lineStyle: {
              width: 2,
              color: '#f5222d'
            },
            itemStyle: {
              color: '#f5222d'
            }
          }
        ]
      };
      
      chart.setOption(option);
      
      // 响应式调整
      window.addEventListener('resize', function() {
        chart.resize();
      });
    },
    
    initGeoDistributionChart() {
      const chartDom = document.getElementById('geoDistributionChart');
      if (!chartDom) return;
      
      const chart = echarts.init(chartDom);
      
      // 简化版地图数据（使用散点图模拟）
      const option = {
        tooltip: {
          trigger: 'item',
          formatter: '{b}: {c} 单'
        },
        visualMap: {
          type: 'piecewise',
          pieces: [
            {min: 1000, label: '1000单以上', color: '#f5222d'},
            {min: 500, max: 999, label: '500-999单', color: '#fa541c'},
            {min: 200, max: 499, label: '200-499单', color: '#faad14'},
            {min: 100, max: 199, label: '100-199单', color: '#a0d911'},
            {min: 1, max: 99, label: '1-99单', color: '#52c41a'}
          ],
          left: 'left',
          top: 'bottom',
          textStyle: {
            color: '#666'
          }
        },
        series: [{
          name: '订单分布',
          type: 'scatter',
          coordinateSystem: 'cartesian2d',
          symbolSize: function (val) {
            return Math.sqrt(val[2]) * 4;
          },
          data: [
            [100, 100, 1450], // 北京
            [120, 90, 820],   // 天津
            [130, 120, 1680], // 上海
            [80, 130, 950],   // 重庆
            [110, 80, 680],   // 河北
            [90, 70, 420],    // 山西
            [140, 60, 780],   // 辽宁
            [150, 50, 350],   // 吉林
            [160, 40, 320],   // 黑龙江
            [125, 110, 1250], // 江苏
            [135, 125, 1420], // 浙江
            [115, 115, 580],  // 安徽
            [140, 130, 890],  // 福建
            [120, 125, 460],  // 江西
            [115, 85, 1120],  // 山东
            [105, 95, 980],   // 河南
            [110, 110, 760],  // 湖北
            [105, 120, 690],  // 湖南
            [120, 140, 1980], // 广东
            [110, 150, 280],  // 海南
            [75, 115, 1150],  // 四川
            [70, 125, 380],   // 贵州
            [65, 135, 420],   // 云南
            [85, 95, 550],    // 陕西
            [70, 80, 290],    // 甘肃
            [60, 90, 120],    // 青海
            [140, 125, 620],  // 香港
            [135, 130, 150]   // 澳门
          ],
          label: {
            show: true,
            formatter: function (param) {
              const cities = {
                1450: '北京', 820: '天津', 1680: '上海', 950: '重庆',
                680: '河北', 420: '山西', 780: '辽宁', 350: '吉林',
                320: '黑龙江', 1250: '江苏', 1420: '浙江', 580: '安徽',
                890: '福建', 460: '江西', 1120: '山东', 980: '河南',
                760: '湖北', 690: '湖南', 1980: '广东', 280: '海南',
                1150: '四川', 380: '贵州', 420: '云南', 550: '陕西',
                290: '甘肃', 120: '青海', 620: '香港', 150: '澳门'
              };
              return cities[param.data[2]] || '';
            },
            position: 'top'
          },
          itemStyle: {
            color: function(param) {
              const value = param.data[2];
              if (value >= 1000) return '#f5222d';
              if (value >= 500) return '#fa541c';
              if (value >= 200) return '#faad14';
              if (value >= 100) return '#a0d911';
              return '#52c41a';
            }
          }
        }],
        xAxis: {
          type: 'value',
          show: false
        },
        yAxis: {
          type: 'value',
          show: false
        }
      };
      
      chart.setOption(option);
      
      // 响应式调整
      window.addEventListener('resize', function() {
        chart.resize();
      });
    }
  }
}
</script>

<style scoped>
.ecommerce-analysis {
  padding: 20px;
}

.page-header {
  margin-bottom: 24px;
}

.page-header h1 {
  color: #303133;
  margin-bottom: 8px;
  font-size: 24px;
}

.page-header p {
  color: #606266;
  font-size: 14px;
}

.stats-cards {
  margin-bottom: 24px;
}

.stats-card {
  border-radius: 8px;
}

.card-content {
  display: flex;
  align-items: center;
}

.card-icon {
  width: 60px;
  height: 60px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 16px;
}

.card-icon .anticon {
  font-size: 24px;
  color: white;
}

.card-info h3 {
  color: #909399;
  font-size: 14px;
  margin: 0 0 8px 0;
}

.card-info .number {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
  margin-bottom: 4px;
}

.card-info .trend {
  font-size: 12px;
}

.trend.up {
  color: #52c41a;
}

.trend.down {
  color: #f5222d;
}

.chart-area {
  margin-top: 20px;
}

.chart-card {
  border-radius: 8px;
}

.chart-container {
  height: 400px;
  width: 100%;
}
</style>