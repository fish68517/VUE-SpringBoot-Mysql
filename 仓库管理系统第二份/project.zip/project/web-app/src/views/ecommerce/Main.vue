<template>
  <div class="ecommerce-main">
    <div class="page-header">
      <h1>电子商务管理中心</h1>
      <p>管理您的在线商务运营</p>
    </div>

    <a-row :gutter="20" class="stats-cards">
      <a-col :span="6">
        <a-card class="stats-card">
          <div class="card-content">
            <div class="card-icon" style="background: #1890ff;">
              <a-icon type="shopping" />
            </div>
            <div class="card-info">
              <h3>商品总数</h3>
              <div class="number">256</div>
              <div class="trend up">↑ 新增12个</div>
            </div>
          </div>
        </a-card>
      </a-col>

      <a-col :span="6">
        <a-card class="stats-card">
          <div class="card-content">
            <div class="card-icon" style="background: #52c41a;">
              <a-icon type="solution" />
            </div>
            <div class="card-info">
              <h3>今日订单</h3>
              <div class="number">89</div>
              <div class="trend up">↑ 较昨日+15%</div>
            </div>
          </div>
        </a-card>
      </a-col>

      <a-col :span="6">
        <a-card class="stats-card">
          <div class="card-content">
            <div class="card-icon" style="background: #faad14;">
              <a-icon type="dollar" />
            </div>
            <div class="card-info">
              <h3>今日收入</h3>
              <div class="number">¥8,642</div>
              <div class="trend up">↑ 较昨日+8%</div>
            </div>
          </div>
        </a-card>
      </a-col>

      <a-col :span="6">
        <a-card class="stats-card">
          <div class="card-content">
            <div class="card-icon" style="background: #f5222d;">
              <a-icon type="team" />
            </div>
            <div class="card-info">
              <h3>在线客户</h3>
              <div class="number">1,234</div>
              <div class="trend up">↑ 活跃用户</div>
            </div>
          </div>
        </a-card>
      </a-col>
    </a-row>

    <a-row :gutter="20" class="action-cards">
      <a-col :span="8">
        <a-card title="商品管理" class="action-card">
          <div class="action-content">
            <a-icon type="appstore" style="font-size: 48px; color: #1890ff; margin-bottom: 16px;" />
            <p>管理商品信息、库存和分类</p>
            <a-button type="primary" @click="goToCommodity">进入管理</a-button>
          </div>
        </a-card>
      </a-col>

      <a-col :span="8">
        <a-card title="订单处理" class="action-card">
          <div class="action-content">
            <a-icon type="file-text" style="font-size: 48px; color: #52c41a; margin-bottom: 16px;" />
            <p>查看和处理客户订单</p>
            <a-button type="primary" @click="goToOrders">查看订单</a-button>
          </div>
        </a-card>
      </a-col>

      <a-col :span="8">
        <a-card title="客户服务" class="action-card">
          <div class="action-content">
            <a-icon type="customer-service" style="font-size: 48px; color: #faad14; margin-bottom: 16px;" />
            <p>处理客户咨询和售后服务</p>
            <a-button type="primary" @click="goToService">客户服务</a-button>
          </div>
        </a-card>
      </a-col>
    </a-row>
  </div>
</template>

<script>
export default {
  name: 'EcommerceMain',
  methods: {
    goToCommodity() {
      this.$router.push('/basics/commodity')
    },
    goToOrders() {
      this.$router.push('/sale/record')
    },
    goToService() {
      this.$message.info('客户服务功能开发中...')
    }
  },
  mounted() {
    console.log('电子商务主页面加载完成')
  }
}
</script>

<style scoped>
.ecommerce-main {
  padding: 20px;
}

.page-header {
  margin-bottom: 24px;
}

.page-header h1 {
  color: #303133;
  margin-bottom: 8px;
}

.page-header p {
  color: #606266;
  font-size: 14px;
}

.stats-cards {
  margin-bottom: 24px;
}

.stats-card {
  border-radius: 8px;
}

.card-content {
  display: flex;
  align-items: center;
}

.card-icon {
  width: 60px;
  height: 60px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-right: 16px;
}

.card-icon .anticon {
  font-size: 24px;
  color: white;
}

.card-info h3 {
  color: #909399;
  font-size: 14px;
  margin: 0 0 8px 0;
}

.card-info .number {
  font-size: 24px;
  font-weight: bold;
  color: #303133;
  margin-bottom: 4px;
}

.card-info .trend {
  font-size: 12px;
}

.trend.up {
  color: #52c41a;
}

.action-cards {
  margin-bottom: 24px;
}

.action-card {
  border-radius: 8px;
  text-align: center;
}

.action-content {
  padding: 20px 0;
}

.action-content p {
  color: #606266;
  margin-bottom: 16px;
}
</style>