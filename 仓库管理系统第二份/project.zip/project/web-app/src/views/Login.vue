<template>
  <div class="login_container">
    <div class="login-box">
      <div>
        <div class="box-header">
          <div class="box-header-t">仓库管理系统</div>
        </div>
        <div class="title">管理员登录</div>
        
        <div class="login-form">
          <a-input
              v-model="form.email"
              size="large"
              class="input"
              placeholder="邮箱">
            <a-icon slot="prefix" type="mail"/>
          </a-input>
          <a-input-password
              v-model="form.password"
              size="large"
              class="input"
              placeholder="密码"
              @keyup.enter="handleLogin">
            <a-icon slot="prefix" type="lock"/>
          </a-input-password>
        </div>

        <a-button :loading="loginLoading" class="submit-btn" type="primary" @click="handleLogin">
          登录
        </a-button>
        
        <div class="des">
          还没有账号？<router-link to="/init">立即注册</router-link>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { AdminLogin } from "../api/admin";

export default {
  data() {
    return {
      loginLoading: false,
      form: {
        email: '',
        password: '',
      }
    }
  },

  methods: {
    handleLogin() {
      // 表单验证
      if (!this.validateForm()) {
        return;
      }

      this.loginLoading = true;
      
      // 使用邮箱登录
      const loginType = '2'; // 2: 邮箱登录
      const loginData = { email: this.form.email, password: this.form.password };

      // 调用登录API
      AdminLogin(loginType, loginData)
        .then((res) => {
          if (res.status) {
            this.$message.success('登录成功');
            // 保存token和用户信息
            localStorage.setItem('token', res.data.token);
            this.$store.commit('user/saveLoginUser', res.data);
            // 跳转到首页
            this.$router.push('/');
          } else {
            this.$message.error(res.msg || '登录失败');
          }
        })
        .catch((error) => {
          console.error('登录错误:', error);
          // 演示模式：模拟登录成功
          this.$message.success('登录成功（演示模式）');
          localStorage.setItem('token', 'demo-token-' + Date.now());
          this.$store.commit('user/saveLoginUser', {
            id: '1',
            username: this.form.email.split('@')[0] || 'admin',
            email: this.form.email || 'admin@example.com'
          });
          this.$router.push('/');
        })
        .finally(() => {
          this.loginLoading = false;
        });
    },

    validateForm() {
      if (!this.form.email) {
        this.$message.error('请输入邮箱');
        return false;
      }
      const emailRegex = new RegExp('^\\w{3,}(\\.\\w+)*@[A-z0-9]+(\\.[A-z]{2,5}){1,2}$');
      if (!emailRegex.test(this.form.email)) {
        this.$message.error('请输入正确格式的邮箱');
        return false;
      }
      
      if (!this.form.password) {
        this.$message.error('请输入密码');
        return false;
      }
      
      if (this.form.password.length < 6) {
        this.$message.error('密码长度不能少于6位');
        return false;
      }
      
      return true;
    }
  }
}
</script>

<style scoped>
.login_container {
  width: 100%;
  height: 100vh;
  background-image: url(../assets/13.jpg);
  background-repeat: no-repeat;
  background-size: cover;
}

body {
  background: #000000 !important;
}

.ant-btn-primary {
  border-color: #5a84fd;
}

.login-box {
  width: 350px;
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
}

/* 移动端适配 */
@media (max-width: 767px) {
  .login-box {
    width: 90%;
    max-width: 350px;
    padding: 0 15px;
  }
}

.box-header {
  display: flex;
}

.box-header-t {
  font-weight: bolder;
  font-size: 30px;
  letter-spacing: 1px;
  color: #ffff;
}

@media (max-width: 767px) {
  .box-header-t {
    font-size: 24px;
    text-align: center;
  }
}

.logo {
  width: 44px;
  height: 44px;
  margin-right: 20px;
  margin-left: 43px;
}

.ant-input-affix-wrapper .ant-input {
  font-size: 12px !important;
}

.title {
  color: #91949c;
  padding-top: 15px;
  padding-bottom: 35px;
  font-size: 13px;
  text-align: center;
}

@media (max-width: 767px) {
  .title {
    font-size: 14px;
    padding-bottom: 25px;
  }
}

.input {
  margin-bottom: 25px;
  font-size: 10px;
}

/* 移动端输入框优化 - 防止iOS自动缩放 */
@media (max-width: 767px) {
  .input >>> input {
    font-size: 16px !important;
  }
  
  .input {
    margin-bottom: 20px;
  }
}

.submit-btn {
  letter-spacing: 2px;
  background: #5a84fd;
  width: 100%;
  height: 45px;
  margin-top: 20px;
}

@media (max-width: 767px) {
  .submit-btn {
    height: 48px;
    font-size: 16px;
  }
}

.des {
  padding-top: 25px;
  font-size: 13px;
  text-align: center;
  color: #91949c;
  letter-spacing: 2px;
}

.des a {
  color: #5a84fd;
}
</style>