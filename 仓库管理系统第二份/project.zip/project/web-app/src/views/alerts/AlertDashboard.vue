<template>
  <div class="dashboard-container">
    <el-alert
      title="成功连接到后端API"
      type="success"
      description="已连接到库存预警服务(端口:8088)，正在使用真实数据。"
      show-icon
      closable
      style="margin-bottom: 20px;"
    />

    <el-row :gutter="20">
      <el-col :span="6">
        <el-card class="stat-card">
          <div class="stat-item">
            <div class="stat-value warning">{{ alertStats.total || 0 }}</div>
            <div class="stat-label">总预警数</div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card class="stat-card">
          <div class="stat-item">
            <div class="stat-value high-risk">{{ alertStats.high || 0 }}</div>
            <div class="stat-label">高风险预警</div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card class="stat-card">
          <div class="stat-item">
            <div class="stat-value medium-risk">{{ alertStats.medium || 0 }}</div>
            <div class="stat-label">中风险预警</div>
          </div>
        </el-card>
      </el-col>
      <el-col :span="6">
        <el-card class="stat-card">
          <div class="stat-item">
            <div class="stat-value low-risk">{{ alertStats.low || 0 }}</div>
            <div class="stat-label">低风险预警</div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 操作按钮 -->
    <el-row :gutter="20" style="margin-top: 20px;">
      <el-col :span="24">
        <el-card>
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <div>
              <h3 style="margin: 0;">库存预警管理</h3>
              <p style="margin: 5px 0 0 0; color: #666; font-size: 14px;">
                <el-tag type="success">生产模式 - 真实数据</el-tag>
                <el-tag type="info" style="margin-left: 5px;">端口:8088</el-tag>
              </p>
            </div>
            <div>
              <el-button @click="loadAlerts" type="primary" :loading="loading">
                <i class="el-icon-refresh"></i>
                刷新数据
              </el-button>
              <el-button @click="checkNow" style="margin-left: 10px;" :loading="checking">
                <i class="el-icon-warning"></i>
                立即检查
              </el-button>
              <el-button @click="testAllApis" style="margin-left: 10px;" type="info">
                <i class="el-icon-connection"></i>
                测试API
              </el-button>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- API测试结果 -->
    <el-row :gutter="20" style="margin-top: 20px;" v-if="testResults.length > 0">
      <el-col :span="24">
        <el-card>
          <h3 style="margin-top: 0;">API测试结果</h3>
          <div v-for="(result, index) in testResults" :key="index" class="test-result">
            <el-tag :type="result.success ? 'success' : 'danger'" size="small">
              {{ result.success ? '成功' : '失败' }}
            </el-tag>
            <span style="margin-left: 10px; font-weight: 500;">{{ result.name }}</span>
            <span style="margin-left: 10px; color: #666;">{{ result.url }}</span>
            <span style="margin-left: 10px; color: #999;">{{ result.message }}</span>
          </div>
        </el-card>
      </el-col>
    </el-row>

    <!-- 预警列表 -->
    <el-row :gutter="20" style="margin-top: 20px;">
      <el-col :span="24">
        <el-card>
          <el-table 
            :data="alerts" 
            :loading="loading"
            style="width: 100%"
            empty-text="暂无预警信息"
          >
            <el-table-column label="预警级别" width="120">
              <template slot-scope="{ row }">
                <el-tag :type="getLevelTagType(row.alertLevel)" effect="light">
                  {{ getLevelText(row.alertLevel) }}
                </el-tag>
              </template>
            </el-table-column>
            
            <el-table-column label="预警类型" width="120">
              <template slot-scope="{ row }">
                <el-tag :type="getTypeTagType(row.alertType)" effect="light">
                  {{ getTypeText(row.alertType) }}
                </el-tag>
              </template>
            </el-table-column>
            
            <el-table-column label="商品ID" prop="productId" width="100" />
            
            <el-table-column label="当前值" prop="currentValue" width="100" />
            
            <el-table-column label="阈值" prop="thresholdValue" width="100" />
            
            <el-table-column label="预警信息" prop="message" min-width="300" />
            
            <el-table-column label="创建时间" width="180">
              <template slot-scope="{ row }">
                {{ formatTime(row.createdTime) }}
              </template>
            </el-table-column>
            
            <el-table-column label="状态" width="100">
              <template slot-scope="{ row }">
                <el-tag :type="row.isResolved ? 'success' : 'warning'">
                  {{ row.isResolved ? '已处理' : '待处理' }}
                </el-tag>
              </template>
            </el-table-column>
            
            <el-table-column label="操作" width="150" fixed="right">
              <template slot-scope="{ row }">
                <el-button 
                  size="small" 
                  @click="resolveAlert(row)"
                  :disabled="row.isResolved"
                >
                  标记处理
                </el-button>
                <el-button 
                  size="small" 
                  type="primary" 
                  @click="viewDetails(row)"
                >
                  详情
                </el-button>
              </template>
            </el-table-column>
          </el-table>

          <!-- 分页 -->
          <div style="margin-top: 20px; display: flex; justify-content: space-between; align-items: center;">
            <span>共 {{ alerts.length }} 条记录</span>
            <div>
              <el-button 
                size="small" 
                :disabled="pagination.current === 1"
                @click="handlePrevPage"
              >
                上一页
              </el-button>
              <span style="margin: 0 10px;">第 {{ pagination.current }} 页</span>
              <el-button 
                size="small" 
                :disabled="pagination.current * pagination.pageSize >= pagination.total"
                @click="handleNextPage"
              >
                下一页
              </el-button>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import { GetActiveAlerts, GetAlertStats, GetHighPriorityAlerts, CheckAlertsNow, ResolveAlert } from "../../api/alert";

export default {
  name: 'AlertDashboard',
  data() {
    return {
      loading: false,
      checking: false,
      alerts: [],
      alertStats: {},
      testResults: [],
      pagination: {
        current: 1,
        pageSize: 10,
        total: 0
      }
    }
  },
  mounted() {
    this.loadAlerts()
  },
  methods: {

    // 测试所有API
    async testAllApis() {
      this.testResults = []
      const apis = [
        { name: '预警列表', func: GetActiveAlerts },
        { name: '统计数据', func: GetAlertStats },
        { name: '高优先级', func: GetHighPriorityAlerts },
        { name: '立即检查', func: CheckAlertsNow }
      ]

      for (const api of apis) {
        try {
          const data = await api.func()
          
          let dataCount = 0
          let success = data.status // 使用 status 字段
          
          // 精确适配后端响应格式
          if (data.status) {
            if (data.data && data.data.data && Array.isArray(data.data.data)) {
              dataCount = data.data.data.length
            } else if (data.data && Array.isArray(data.data)) {
              dataCount = data.data.length
            } else if (data.data && typeof data.data === 'object') {
              // 对于stats接口，data是对象
              dataCount = Object.keys(data.data).length
            }
          }
          
          this.testResults.push({
            success: success,
            name: api.name,
            url: '使用通用API配置',
            message: success ? `成功 (${dataCount}条数据)` : (data.msg || '请求失败')
          })
        } catch (error) {
          this.testResults.push({
            success: false,
            name: api.name,
            url: '使用通用API配置',
            message: error.message
          })
        }
      }
    },

    async loadAlerts() {
      this.loading = true
      try {
        console.log('🔍 开始加载预警数据...')
        
        // 使用项目中的通用API配置
        const alertData = await GetActiveAlerts()
        console.log('📡 预警API响应:', alertData)
        
        // 🔧 精确修复：适配 {code: 200, status: true, msg: null, data: {data: [...], total: X, success: true}}
        if (alertData.status) {
          let alertList = []
          
          // 精确解析：data.data 才是真正的预警数组
          if (alertData.data && alertData.data.data && Array.isArray(alertData.data.data)) {
            alertList = alertData.data.data
            console.log('✅ 使用 data.data.data 格式')
          } else if (alertData.data && Array.isArray(alertData.data)) {
            alertList = alertData.data
            console.log('✅ 使用 data.data 格式')
          } else {
            alertList = []
            console.log('❌ 无法识别的数据格式')
          }
          
          this.alerts = alertList
          this.pagination.total = alertList.length
          
          console.log('✅ 成功加载预警数据:', alertList.length, '条')
          console.log('📊 预警数据详情:', alertList)
          
          // 计算统计数据
          this.calculateStats()
          
          this.$message.success(`成功加载 ${alertList.length} 条预警数据`)
        } else {
          throw new Error(alertData.msg || '获取预警列表失败')
        }

      } catch (error) {
        console.error('❌ 加载预警数据失败:', error)
        this.$message.error('加载数据失败: ' + error.message)
        // 失败时使用模拟数据
        this.generateMockData()
      } finally {
        this.loading = false
      }
    },

    // 计算统计数据
    calculateStats() {
      const stats = {
        total: this.alerts.length,
        high: this.alerts.filter(a => a.alertLevel === 'HIGH').length,
        medium: this.alerts.filter(a => a.alertLevel === 'MEDIUM').length,
        low: this.alerts.filter(a => a.alertLevel === 'LOW').length
      }
      this.alertStats = stats
      console.log('📊 统计计算完成:', stats)
    },

    // 生成模拟数据（备用）
    generateMockData() {
      console.log('🔄 使用模拟数据')
      this.alerts = [
        {
          id: 1,
          productId: 1,
          alertType: 'LOW_STOCK',
          alertLevel: 'LOW',
          currentValue: 15,
          thresholdValue: 20,
          message: '商品【ID:1】库存过低！当前库存：15，安全库存：20',
          isResolved: false,
          createdTime: new Date('2024-01-15 10:30:00')
        },
        {
          id: 2,
          productId: 2,
          alertType: 'OVER_STOCK',
          alertLevel: 'HIGH',
          currentValue: 200,
          thresholdValue: 100,
          message: '商品【ID:2】库存积压！当前库存：200，最大库存：100',
          isResolved: false,
          createdTime: new Date('2024-01-15 09:15:00')
        }
      ]
      this.pagination.total = this.alerts.length
      this.calculateStats()
    },

    async checkNow() {
      this.checking = true
      try {
        console.log('🔄 开始立即检查预警...')
        
        // 使用项目中的通用API配置
        const data = await CheckAlertsNow()
        console.log('📡 立即检查响应:', data)
        
        // 🔧 修复：适配后端格式 {code: 200, status: true, msg: '...'}
        if (data.status) {
          this.$message.success(data.msg || '预警检查完成')
          // 重新加载数据
          this.loadAlerts()
        } else {
          this.$message.error(data.msg || '检查失败')
        }
      } catch (error) {
        console.error('❌ 预警检查失败:', error)
        this.$message.error('预警检查失败: ' + error.message)
      } finally {
        this.checking = false
      }
    },

    async resolveAlert(alert) {
      try {
        await this.$confirm('确定要标记该预警为已处理吗？', '确认处理', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        })

        console.log('🔄 处理预警:', alert.id)
        
        // 使用项目中的通用API配置
        const data = await ResolveAlert(alert.id, 1)
        console.log('📡 处理预警响应:', data)
        
        // 🔧 修复：适配后端格式
        if (data.status) {
          this.$message.success(data.msg || '预警已标记为已处理')
          this.loadAlerts()
        } else {
          this.$message.error(data.msg || '处理失败')
        }

      } catch (error) {
        if (error !== 'cancel') {
          console.error('❌ 处理预警失败:', error)
          this.$message.error('处理失败: ' + error.message)
        }
      }
    },

    viewDetails(alert) {
      this.$message.info('查看商品 ' + alert.productId + ' 的详情')
      console.log('🔍 查看预警详情:', alert)
      // 这里可以跳转到商品详情页面
      // this.$router.push('/product/detail/' + alert.productId)
    },

    getLevelTagType(level) {
      const types = {
        'HIGH': 'danger',
        'MEDIUM': 'warning',
        'LOW': 'info'
      }
      return types[level] || 'info'
    },

    getLevelText(level) {
      const texts = {
        'HIGH': '高风险',
        'MEDIUM': '中风险',
        'LOW': '低风险'
      }
      return texts[level] || level
    },

    getTypeTagType(type) {
      const types = {
        'LOW_STOCK': 'danger',
        'OVER_STOCK': 'warning'
      }
      return types[type] || 'info'
    },

    getTypeText(type) {
      const texts = {
        'LOW_STOCK': '低库存',
        'OVER_STOCK': '高库存'
      }
      return texts[type] || type
    },

    formatTime(time) {
      if (!time) return '-'
      return new Date(time).toLocaleString('zh-CN')
    },

    handlePrevPage() {
      if (this.pagination.current > 1) {
        this.pagination.current--
      }
    },

    handleNextPage() {
      if (this.pagination.current * this.pagination.pageSize < this.pagination.total) {
        this.pagination.current++
      }
    }
  }
}
</script>

<style scoped>
.dashboard-container {
  padding: 20px;
  background-color: #f5f7fa;
  min-height: 100vh;
}

.stat-card {
  text-align: center;
  border-radius: 8px;
}

.stat-item {
  padding: 10px 0;
}

.stat-value {
  font-size: 32px;
  font-weight: bold;
  margin-bottom: 8px;
}

.stat-label {
  font-size: 14px;
  color: #909399;
}

.warning {
  color: #e6a23c;
}

.high-risk {
  color: #f56c6c;
}

.medium-risk {
  color: #e6a23c;
}

.low-risk {
  color: #409eff;
}

.test-result {
  margin: 8px 0;
  padding: 8px;
  border-radius: 4px;
  background-color: #f8f9fa;
  border-left: 4px solid #e9ecef;
}

.test-result:last-child {
  margin-bottom: 0;
}
</style>