<template>
  <el-dialog
    v-model="visible"
    title="预警规则配置"
    width="900px"
    :before-close="handleClose"
  >
    <!-- 搜索栏 -->
    <div style="margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
      <div style="display: flex; align-items: center; gap: 10px;">
        <el-input
          v-model="searchText"
          placeholder="搜索商品ID"
          style="width: 250px"
          clearable
          prefix-icon="Search"
        />
        <el-button type="primary" icon="Search">搜索</el-button>
      </div>
      <el-button type="primary" icon="Plus" @click="addNewRule" style="background: linear-gradient(135deg, #667eea, #764ba2); border: none;">
        新增规则
      </el-button>
    </div>

    <!-- 规则表格 -->
    <el-table 
      :data="filteredRules" 
      style="width: 100%; border: 1px solid #e8e8e8; border-radius: 8px;" 
      empty-text="暂无预警规则"
      :header-cell-style="{ 
        background: 'linear-gradient(135deg, #f5f7fa, #e4e7ed)', 
        color: '#606266',
        fontWeight: 'bold',
        borderBottom: '2px solid #e8e8e8'
      }"
      :row-style="{ height: '60px' }"
    >
      <el-table-column label="商品信息" min-width="180">
        <template #default="{ row }">
          <div style="display: flex; flex-direction: column;">
            <span style="font-weight: 600; color: #303133; margin-bottom: 4px;">{{ getProductName(row.productId) }}</span>
            <span style="font-size: 12px; color: #909399;">ID: {{ row.productId }}</span>
          </div>
        </template>
      </el-table-column>
      
      <el-table-column label="预警类型" width="120" align="center">
        <template #default="{ row }">
          <el-tag 
            :type="row.ruleType === 'LOW_STOCK' ? 'danger' : 'warning'" 
            effect="light"
            style="font-weight: 500;"
          >
            {{ row.ruleType === 'LOW_STOCK' ? '低库存预警' : '高库存预警' }}
          </el-tag>
        </template>
      </el-table-column>
      
      <el-table-column label="库存阈值" width="200">
        <template #default="{ row }">
          <div style="display: flex; flex-direction: column; gap: 6px;">
            <div v-if="row.minStock" style="display: flex; align-items: center; gap: 6px; color: #f56c6c; background: #fef0f0; padding: 4px 8px; border-radius: 4px;">
              <el-icon><ArrowDown /></el-icon>
              <span style="font-size: 12px;">最低库存: {{ row.minStock }}</span>
            </div>
            <div v-if="row.maxStock" style="display: flex; align-items: center; gap: 6px; color: #e6a23c; background: #fdf6ec; padding: 4px 8px; border-radius: 4px;">
              <el-icon><ArrowUp /></el-icon>
              <span style="font-size: 12px;">最高库存: {{ row.maxStock }}</span>
            </div>
          </div>
        </template>
      </el-table-column>
      
      <el-table-column label="状态" width="100" align="center">
        <template #default="{ row }">
          <el-switch
            v-model="row.isActive"
            @change="updateRuleStatus(row)"
            style="--el-switch-on-color: #13ce66; --el-switch-off-color: #ff4949;"
          />
        </template>
      </el-table-column>
      
      <el-table-column label="操作" width="150" align="center" fixed="right">
        <template #default="{ row }">
          <div style="display: flex; gap: 8px; justify-content: center;">
            <el-button 
              size="small" 
              type="primary" 
              @click="editRule(row)" 
              text
              style="color: #409EFF;"
            >
              <el-icon><Edit /></el-icon>
              编辑
            </el-button>
            <el-button 
              size="small" 
              type="danger" 
              @click="deleteRule(row)" 
              text
              style="color: #F56C6C;"
            >
              <el-icon><Delete /></el-icon>
              删除
            </el-button>
          </div>
        </template>
      </el-table-column>
    </el-table>

    <template #footer>
      <div style="display: flex; justify-content: flex-end; gap: 12px;">
        <el-button @click="handleClose">关闭</el-button>
        <el-button type="primary" @click="refreshData" style="background: linear-gradient(135deg, #667eea, #764ba2); border: none;">
          <el-icon><Refresh /></el-icon>
          刷新
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, computed } from 'vue'
import { ElMessage, ElMessageBox } from 'element-plus'
import { 
  Plus, 
  Search, 
  Edit, 
  Delete, 
  ArrowDown, 
  ArrowUp,
  Refresh 
} from '@element-plus/icons-vue'

const props = defineProps({
  visible: Boolean
})

const emit = defineEmits(['update:visible', 'close', 'refresh'])

// 响应式数据
const searchText = ref('')
const rules = ref([
  {
    id: 1,
    productId: '1c0e25d3-db1f-4cda-93b1-81101d21dc5b',
    ruleType: 'LOW_STOCK',
    minStock: 50,
    maxStock: null,
    isActive: true
  },
  {
    id: 2,
    productId: '2',
    ruleType: 'OVER_STOCK',
    minStock: null,
    maxStock: 100,
    isActive: true
  },
  {
    id: 3,
    productId: '3ce4732f-61e1-4048-beb7-89dd7b3d99dc',
    ruleType: 'LOW_STOCK',
    minStock: 30,
    maxStock: 150,
    isActive: false
  },
  {
    id: 4,
    productId: '4',
    ruleType: 'LOW_STOCK',
    minStock: 10,
    maxStock: 80,
    isActive: true
  },
  {
    id: 5,
    productId: '7',
    ruleType: 'LOW_STOCK',
    minStock: 5,
    maxStock: null,
    isActive: true
  },
  {
    id: 6,
    productId: '8',
    ruleType: 'OVER_STOCK',
    minStock: null,
    maxStock: 30,
    isActive: true
  }
])

// 计算属性
const filteredRules = computed(() => {
  if (!searchText.value) return rules.value
  return rules.value.filter(rule => 
    rule.productId.includes(searchText.value) ||
    getProductName(rule.productId).includes(searchText.value)
  )
})

// 方法
const handleClose = () => {
  emit('update:visible', false)
  emit('close')
}

const getProductName = (productId) => {
  const productMap = {
    '1c0e25d3-db1f-4cda-93b1-81101d21dc5b': 'iPhone 17 Pro Max',
    '2': '富士高端相机',
    '3ce4732f-61e1-4048-beb7-89dd7b3d99dc': '小米15 Pro',
    '4': '小米16 Pro',
    '7': '苹果16promax',
    '8': '盒马面包'
  }
  return productMap[productId] || `商品 ${productId}`
}

const updateRuleStatus = (rule) => {
  ElMessage.success(`规则已${rule.isActive ? '启用' : '禁用'}`)
}

const editRule = (rule) => {
  ElMessage.info(`编辑规则: ${getProductName(rule.productId)}`)
}

const deleteRule = async (rule) => {
  try {
    await ElMessageBox.confirm(
      `确定要删除【${getProductName(rule.productId)}】的预警规则吗？`,
      '确认删除',
      { 
        type: 'warning',
        confirmButtonText: '确定删除',
        cancelButtonText: '取消'
      }
    )
    
    rules.value = rules.value.filter(r => r.id !== rule.id)
    ElMessage.success('规则已删除')
    emit('refresh')
  } catch (error) {
    if (error !== 'cancel') {
      ElMessage.error('删除失败')
    }
  }
}

const addNewRule = () => {
  ElMessage.info('打开新增规则对话框')
}

const refreshData = () => {
  ElMessage.success('数据已刷新')
}
</script>

<style scoped>
/* 确保样式生效的关键 */
:deep(.el-dialog) {
  border-radius: 12px !important;
  overflow: hidden;
}

:deep(.el-dialog__header) {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
  margin: 0 !important;
  padding: 20px 24px !important;
}

:deep(.el-dialog__title) {
  color: white !important;
  font-weight: 600 !important;
  font-size: 16px !important;
}

:deep(.el-dialog__headerbtn) {
  top: 20px !important;
}

:deep(.el-dialog__headerbtn .el-dialog__close) {
  color: white !important;
  font-size: 18px !important;
}

:deep(.el-dialog__body) {
  padding: 20px 24px !important;
}

:deep(.el-dialog__footer) {
  padding: 16px 24px !important;
  border-top: 1px solid #e8e8e8 !important;
}

/* 表格行悬停效果 */
:deep(.el-table__row:hover) {
  background-color: #f5f7fa !important;
}

:deep(.el-table) {
  border-radius: 8px;
  overflow: hidden;
}

:deep(.el-table th) {
  background: linear-gradient(135deg, #f5f7fa, #e4e7ed) !important;
}
</style>