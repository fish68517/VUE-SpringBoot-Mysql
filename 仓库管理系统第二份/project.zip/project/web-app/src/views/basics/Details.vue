<template>
  <div class="main">
    <div class="header">
      <router-link to="/warehouse">
        <a-icon type="arrow-left" style="padding-right: 5px"/>
        返回上一页
      </router-link>
      <a-alert 
        message="扫码功能测试模式" 
        description="摄像头扫码功能正常工作，使用模拟数据进行演示" 
        type="info" 
        show-icon
        style="margin-top: 10px;"
      />
    </div>
    
    <!-- 扫码操作按钮组 -->
    <div style="display: flex; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
      <a-button class="editable-btn" @click="handleSubmit('in')">
        <a-icon type="plus" />
        入库商品
      </a-button>
      <a-button class="editable-btn" @click="handleSubmit('out')">
        <a-icon type="minus" />
        出库商品
      </a-button>
      
      <!-- 扫码功能按钮 -->
      <a-button class="editable-btn" @click="showScanner('inbound')" type="primary">
        <a-icon type="qrcode" />
        扫码入库
      </a-button>
      <a-button class="editable-btn" @click="showScanner('outbound')" type="primary">
        <a-icon type="qrcode" />
        扫码出库
      </a-button>
      <a-button class="editable-btn" @click="showScanner('query')">
        <a-icon type="search" />
        扫码查询
      </a-button>

      <download-excel
          class="export-excel-wrapper"
          :data="data"
          :fields="json_fields"
          name="库存报表.xls">
        <a-button class="editable-btn">
          <a-icon type="cloud-download"/>
          下载库存报表 Excel
        </a-button>
      </download-excel>
      <a-button class="editable-btn" @click="recordVisible = true">
        <a-icon type="retweet"/>
        出入库记录 Excel
      </a-button>
    </div>

    <a-table :loading="loading" :columns="columns" :data-source="data" rowKey="id">
      <a slot="name" slot-scope="text">{{ text }}</a>
      <span slot="customTitle"><a-icon type="smile-o"/> 商品名</span>
      <span slot="count" slot-scope="count">
        <a-tag color="#108ee9">{{ count }}</a-tag>
      </span>
    </a-table>

    <!-- 原有的入库出库弹窗 -->
    <a-modal
        title="入库 ｜ 出库"
        :closable="false"
        :visible="visible"
        @ok="submit"
        @cancel="visible = false"
    >
      <a-form-model :model="form">
        <a-form-model-item label="请选商品">
          <a-select v-model="selectIndex" placeholder="请选择入库的商品">
            <a-select-option :value="index" v-for="(item, index) in commodityList" :key="index">
              {{ item.name }}
            </a-select-option>
          </a-select>
        </a-form-model-item>
        <a-form-model-item label="商品数量">
          <a-input-number id="inputNumber" v-model="form.count" :min="1"/>
        </a-form-model-item>
        <a-form-model-item label="备注">
          <a-input :rows="4" v-model="form.description" type="textarea"/>
        </a-form-model-item>
      </a-form-model>
    </a-modal>

    <!-- 扫码功能弹窗 -->
    <a-modal
        :title="scannerTitle"
        :visible="scannerVisible"
        width="700px"
        :footer="null"
        @cancel="closeScanner"
        :maskClosable="false"
    >
      <QrCodeScanner
          ref="scanner"
          :title="scannerTitle"
          :operation-type="currentOperation"
          :warehouse-id="id"
          @scanned="onScanned"
          @confirm="onScannerConfirm"
          @cancel="closeScanner"
      />
    </a-modal>

    <a-modal
        title="出入库记录"
        width="80%"
        :visible="recordVisible"
        :footer="null"
        @cancel="recordVisible = false"
    >
      <InventoryRecords :warehouse-id="id"/>
    </a-modal>

  </div>
</template>

<script>
import InventoryRecords from "../../components/InventoryRecords";
import QrCodeScanner from "../../components/QrCodeScanner";
import { FindAllInventory, InAndOut } from "../../api/inventory";

const columns = [
  {
    title: '商品ID',
    dataIndex: 'id',
    key: 'id',
    width: '50%'
  },
  {
    dataIndex: 'name',
    key: 'name',
    slots: {title: 'customTitle'},
    scopedSlots: {customRender: 'name'},
  },
  {
    title: '库存数量',
    dataIndex: 'count',
    key: 'count',
    scopedSlots: {customRender: 'count'},
  },
];

export default {

  components: {InventoryRecords, QrCodeScanner},

  data() {
    return {
      json_fields: {
        "商品ID": "cid",
        "商品名称": "name",
        "库存盘点数量": "count",
      },
      id: this.$route.params.id,
      loading: false,
      visible: false,
      recordVisible: false,
      scannerVisible: false,
      selectIndex: 0,
      commodityVisible: false,
      data: [],
      columns,
      commodityList: [],
      submitType: '',
      
      // 扫码相关数据
      currentOperation: 'query', // 'inbound', 'outbound', 'query'
      scannerTitle: '扫码操作',
      
      form: {
        wid: this.$route.params.id,
        cid: '',
        name: '',
        description: '',
        count: 50,
      },
    }
  },

  mounted() {
    console.log('🔧 调试信息 - 仓库ID:', this.id)
    console.log('🔧 调试信息 - Token:', localStorage.getItem('token'))
    
    this.loadData()
    this.loadCommodityList()
  },

  methods: {

    // 加载商品列表 - 直接使用模拟数据，避免API错误
    loadCommodityList() {
      console.log('🔄 加载商品列表...')
      this.commodityList = [
        { id: '1', name: '笔记本电脑' },
        { id: '2', name: '智能手机' },
        { id: '3', name: '平板电脑' },
        { id: '4', name: '无线耳机' },
        { id: '5', name: '智能手表' },
        { id: '6', name: '数码相机' },
        { id: '7', name: '游戏主机' },
        { id: '8', name: '蓝牙音箱' }
      ]
      console.log('✅ 商品列表加载完成:', this.commodityList.length, '条')
    },

    // 加载库存数据 - 使用项目通用API配置
    loadData() {
      this.loading = true
      console.log('🔄 加载库存数据，仓库ID:', this.id)
      
      // 使用项目中的通用API配置
      FindAllInventory(this.id)
      .then(response => {
        console.log('✅ 库存数据加载完成:', response)
        // 后端返回的数据格式: {code: 200, status: true, data: [{id, cid, wid, name, count}]}
        // 需要从response.data中获取实际的数据数组
        if (response && response.data && Array.isArray(response.data)) {
          this.data = response.data.map(item => ({
            id: item.cid,
            name: item.name,
            count: item.count
          }))
        } else {
          console.error('❌ 响应数据格式不正确:', response)
          this.$message.warning('响应数据格式不正确，使用模拟数据')
          this.data = [
            { id: '1', name: '笔记本电脑', count: 25 },
            { id: '2', name: '智能手机', count: 50 },
            { id: '3', name: '平板电脑', count: 30 },
            { id: '4', name: '无线耳机', count: 100 },
            { id: '5', name: '智能手表', count: 45 },
            { id: '6', name: '数码相机', count: 15 },
            { id: '7', name: '游戏主机', count: 20 },
            { id: '8', name: '蓝牙音箱', count: 60 }
          ]
        }
        this.loading = false
      })
      .catch(error => {
        console.error('❌ 加载库存数据失败:', error)
        this.$message.warning('加载库存数据失败，使用模拟数据')
        // 失败时使用模拟数据
        this.data = [
          { id: '1', name: '笔记本电脑', count: 25 },
          { id: '2', name: '智能手机', count: 50 },
          { id: '3', name: '平板电脑', count: 30 },
          { id: '4', name: '无线耳机', count: 100 },
          { id: '5', name: '智能手表', count: 45 },
          { id: '6', name: '数码相机', count: 15 },
          { id: '7', name: '游戏主机', count: 20 },
          { id: '8', name: '蓝牙音箱', count: 60 }
        ]
        this.loading = false
      })
    },

    handleSubmit(type) {
      this.submitType = type
      this.visible = true
    },

    // 显示扫码弹窗
    showScanner(operation) {
      this.currentOperation = operation
      this.scannerTitle = this.getScannerTitle(operation)
      this.scannerVisible = true
    },

    // 关闭扫码弹窗
    closeScanner() {
      this.scannerVisible = false
      this.currentOperation = 'query'
    },

    // 获取扫码弹窗标题
    getScannerTitle(operation) {
      const titles = {
        'inbound': '扫码入库',
        'outbound': '扫码出库', 
        'query': '扫码查询'
      }
      return titles[operation] || '扫码操作'
    },

    // 扫码成功回调
    onScanned(barcode) {
      console.log('📱 扫描到条码:', barcode)
    },

    // 扫码确认操作 - 连接真实后端API
    async onScannerConfirm(operationData) {
      console.log('📦 扫码操作确认:', operationData)
      
      try {
        // 🔥 优先使用二维码中的 type 信息，如果没有则使用 operationType
        let finalOperationType = operationData.operationType
        let operationTypeText = this.getOperationText(operationData.operationType)
        
        if (operationData.qrCodeType) {
          // 二维码中有 type 信息 (IN/OUT)，使用它
          finalOperationType = operationData.qrCodeType === 'IN' ? 'inbound' : 'outbound'
          operationTypeText = operationData.qrCodeType === 'IN' ? '入库' : '出库'
          console.log('🎯 使用二维码中的操作类型:', operationData.qrCodeType, '-> ', finalOperationType)
        } else {
          console.log('🎯 使用 prop 中的操作类型:', finalOperationType)
        }
        
        // 获取商品信息
        let productId, productName, quantity, description
        
        // 如果有二维码原始数据，优先使用
        if (operationData.productInfo && operationData.productInfo.qrData) {
          const qrData = operationData.productInfo.qrData
          productId = qrData.commodityId
          productName = operationData.productInfo.name || `商品-${qrData.commodityId}`
          quantity = operationData.quantity // 使用用户确认的数量
          description = qrData.remark || `扫码${operationTypeText}`
          console.log('📝 使用二维码中的商品信息:', { productId, productName, quantity, description })
        } else {
          // 普通条码扫描
          productId = operationData.productInfo && operationData.productInfo.id 
            ? operationData.productInfo.id 
            : operationData.barcode
          productName = operationData.productInfo && operationData.productInfo.name 
            ? operationData.productInfo.name 
            : `商品-${operationData.barcode}`
          quantity = operationData.quantity
          description = `扫码${operationTypeText}`
          console.log('📝 使用普通条码信息:', { productId, productName, quantity, description })
        }

        // 构建请求数据
        const requestData = {
          wid: this.id,
          cid: productId,
          name: productName,
          count: quantity,
          description: description
        }

        console.log('🔄 执行API请求:', requestData)

        // 🔥 判断操作类型：入库(in)或出库(out)
        const apiType = finalOperationType === 'inbound' ? 'in' : 'out'
        console.log('🚪 调用接口类型:', apiType, '(入库=in, 出库=out)')
        
        // 使用项目中的通用API配置
        const result = await InAndOut(apiType, requestData)
        console.log('✅ API响应:', result)
        
        this.$message.success(`${operationTypeText}操作成功！`)
        this.loadData() // 重新加载库存数据
        this.closeScanner()
        
      } catch (error) {
        console.error('❌ 操作失败:', error)
        this.$message.error('操作失败: ' + (error.message || '未知错误'))
      }
    },

    // 模拟更新库存数据
    updateInventoryData(operationInfo) {
      const { operationType, quantity, barcode } = operationInfo
      
      // 在现有数据中查找或添加商品
      const existingProduct = this.data.find(item => item.id === barcode)
      
      if (existingProduct) {
        // 更新现有商品库存
        if (operationType === 'inbound') {
          existingProduct.count += quantity
        } else if (operationType === 'outbound') {
          existingProduct.count = Math.max(0, existingProduct.count - quantity)
        }
      } else {
        // 添加新商品
        const newProduct = {
          id: barcode,
          name: `商品-${barcode}`,
          count: operationType === 'inbound' ? quantity : 0
        }
        this.data.push(newProduct)
      }
      
      console.log('📊 库存数据已更新')
    },

    // 获取操作类型文本
    getOperationText(operationType) {
      const texts = {
        'inbound': '入库',
        'outbound': '出库',
        'query': '查询'
      }
      return texts[operationType] || '操作'
    },

    // 原有的提交方法 - 使用模拟操作
    submit() {
      this.form.cid = this.commodityList[this.selectIndex].id
      this.form.name = this.commodityList[this.selectIndex].name
      
      console.log('📝 提交表单数据:', this.form)
      
      // 模拟API调用
      setTimeout(() => {
        this.$message.success(`${this.submitType === 'in' ? '入库' : '出库'}操作成功！`)
        this.visible = false
        
        // 更新库存数据
        this.updateManualInventoryData()
        this.loadData()
      }, 1000)
    },

    // 更新手动操作的库存数据
    updateManualInventoryData() {
      const productId = this.form.cid
      const quantity = this.form.count
      const isInbound = this.submitType === 'in'
      
      const existingProduct = this.data.find(item => item.id === productId)
      
      if (existingProduct) {
        if (isInbound) {
          existingProduct.count += quantity
        } else {
          existingProduct.count = Math.max(0, existingProduct.count - quantity)
        }
      }
    },
  }
}
</script>

<style scoped>
.main {
  background: #ffffff;
  padding: 30px;
}

.header {
  font-size: 18px;
  margin-bottom: 40px;
}

a {
  color: #000000;
}

.header a:hover {
  color: #5a84fd;
}

.editable-btn {
  margin-bottom: 20px;
  margin-right: 10px;
}

.in-icon {
  transform: rotate(270deg);
}

/* 扫码按钮特殊样式 */
.editable-btn.ant-btn-primary {
  background: #1890ff;
  border-color: #1890ff;
}
</style>