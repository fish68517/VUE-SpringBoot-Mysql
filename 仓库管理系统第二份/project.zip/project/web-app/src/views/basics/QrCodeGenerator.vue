<template>
  <div class="qr-generator-container">
    <a-card title="二维码生成器" :bordered="false" style="max-width: 800px; margin: 0 auto;">
      <a-form-model ref="qrForm" :model="formData" :label-col="{ span: 6 }" :wrapper-col="{ span: 16 }">
        
        <!-- 出库/入库类型选择 -->
        <a-form-model-item label="操作类型" required>
          <a-radio-group v-model="formData.operationType" button-style="solid" size="large">
            <a-radio-button value="IN">
              <a-icon type="login" />
              入库
            </a-radio-button>
            <a-radio-button value="OUT">
              <a-icon type="logout" />
              出库
            </a-radio-button>
          </a-radio-group>
        </a-form-model-item>

        <!-- 商品选择 -->
        <a-form-model-item label="商品选择" required>
          <a-select
            v-model="formData.commodityId"
            placeholder="请选择商品"
            size="large"
            show-search
            :filter-option="filterOption"
            @change="onCommodityChange"
          >
            <a-select-option
              v-for="commodity in commodityList"
              :key="commodity.id"
              :value="commodity.id"
              :label="`${commodity.name} (${commodity.id})`"
            >
              {{ commodity.name }} - ID: {{ commodity.id }}
            </a-select-option>
          </a-select>
          <div style="margin-top: 8px; color: #666; font-size: 12px;">
            当前选中: {{ selectedCommodity ? selectedCommodity.name : '未选择' }}
          </div>
        </a-form-model-item>

        <!-- 产品数量 -->
        <a-form-model-item label="产品数量" required>
          <a-input-number 
            v-model="formData.quantity" 
            :min="1"
            :max="99999"
            style="width: 100%"
            size="large"
            placeholder="请输入产品数量"
          />
        </a-form-model-item>

        <!-- 备注 -->
        <a-form-model-item label="备注信息">
          <a-textarea 
            v-model="formData.remark" 
            placeholder="请输入备注信息（可选）"
            :rows="4"
            :maxLength="200"
            show-count
          />
        </a-form-model-item>

        <!-- 生成按钮 -->
        <a-form-model-item :wrapper-col="{ span: 16, offset: 6 }">
          <a-button 
            type="primary" 
            size="large"
            @click="generateQrCode"
            :loading="generating"
            block
          >
            <a-icon type="qrcode" />
            生成二维码
          </a-button>
        </a-form-model-item>
      </a-form-model>

      <!-- 二维码显示区域 -->
      <div v-if="qrCodeGenerated" class="qr-display-area">
        <a-divider>生成的二维码</a-divider>
        
        <div class="qr-info-card">
          <a-row :gutter="16">
            <a-col :span="12">
              <div class="info-item">
                <span class="info-label">操作类型:</span>
                <a-tag :color="formData.operationType === 'IN' ? 'green' : 'orange'">
                  {{ formData.operationType === 'IN' ? '入库' : '出库' }}
                </a-tag>
              </div>
              <div class="info-item">
                <span class="info-label">商品ID:</span>
                <span class="info-value">{{ formData.commodityId }}</span>
              </div>
              <div class="info-item" v-if="selectedCommodity">
                <span class="info-label">商品名称:</span>
                <span class="info-value">{{ selectedCommodity.name }}</span>
              </div>
            </a-col>
            <a-col :span="12">
              <div class="info-item">
                <span class="info-label">产品数量:</span>
                <span class="info-value">{{ formData.quantity }}</span>
              </div>
              <div class="info-item" v-if="formData.remark">
                <span class="info-label">备注:</span>
                <span class="info-value">{{ formData.remark }}</span>
              </div>
            </a-col>
          </a-row>
        </div>

        <div class="qr-code-wrapper">
          <canvas ref="qrCanvas" class="qr-canvas"></canvas>
        </div>

        <div class="qr-actions">
          <a-button type="primary" @click="downloadQrCode" size="large">
            <a-icon type="download" />
            下载二维码
          </a-button>
          <a-button @click="resetForm" size="large" style="margin-left: 10px">
            <a-icon type="reload" />
            重新生成
          </a-button>
        </div>
      </div>
    </a-card>
  </div>
</template>

<script>
import QRCode from 'qrcode'
import { FindAllCommodity } from "@/api/commodity"

export default {
  name: 'QrCodeGenerator',
  data() {
    return {
      formData: {
        operationType: 'IN',
        commodityId: '',
        quantity: 1,
        remark: ''
      },
      generating: false,
      qrCodeGenerated: false,
      qrCodeData: '',
      commodityList: [],
      commodityLoading: false,
      selectedCommodity: null
    }
  },
  mounted() {
    this.loadCommodityList()
  },
  methods: {
    // 加载商品列表
    loadCommodityList() {
      this.commodityLoading = true
      FindAllCommodity()
        .then(response => {
          console.log('✅ 商品列表加载完成:', response)
          if (response && response.data && Array.isArray(response.data)) {
            this.commodityList = response.data
          } else {
            console.error('❌ 商品数据格式不正确:', response)
            this.$message.warning('商品数据加载失败')
          }
        })
        .catch(error => {
          console.error('❌ 加载商品列表失败:', error)
          this.$message.error('加载商品列表失败')
        })
        .finally(() => {
          this.commodityLoading = false
        })
    },

    // 商品选择变化
    onCommodityChange(commodityId) {
      this.selectedCommodity = this.commodityList.find(item => item.id === commodityId)
      console.log('📦 选择商品:', this.selectedCommodity)
    },

    // 搜索过滤
    filterOption(input, option) {
      const commodity = this.commodityList.find(item => item.id === option.value)
      if (!commodity) return false
      return commodity.name.toLowerCase().includes(input.toLowerCase()) ||
             commodity.id.toLowerCase().includes(input.toLowerCase())
    },

    // 验证表单
    validateForm() {
      if (!this.formData.commodityId) {
        this.$message.warning('请选择商品')
        return false
      }
      if (!this.formData.quantity || this.formData.quantity < 1) {
        this.$message.warning('请输入有效的产品数量')
        return false
      }
      return true
    },

    // 生成二维码
    async generateQrCode() {
      if (!this.validateForm()) {
        return
      }

      this.generating = true

      // 构建二维码数据对象
      const qrData = {
        type: this.formData.operationType,
        commodityId: this.formData.commodityId,
        quantity: this.formData.quantity,
        remark: this.formData.remark,
        timestamp: new Date().getTime()
      }

      // 转换为JSON字符串
      this.qrCodeData = JSON.stringify(qrData)

      try {
        // 先重置状态，确保不会显示之前的结果
        this.qrCodeGenerated = false

        // 等待DOM更新
        await this.$nextTick()

        // 临时显示canvas区域以便获取引用
        this.qrCodeGenerated = true
        await this.$nextTick()

        // 生成二维码到canvas
        const canvas = this.$refs.qrCanvas
        if (!canvas) {
          throw new Error('二维码画布不存在')
        }

        await QRCode.toCanvas(canvas, this.qrCodeData, {
          width: 300,
          margin: 2,
          color: {
            dark: '#000000',
            light: '#FFFFFF'
          }
        })

        // 添加延迟确保二维码完全渲染
        await new Promise(resolve => setTimeout(resolve, 300))
        
        const ctx = canvas.getContext('2d')
        if (!ctx) {
          throw new Error('无法获取canvas上下文')
        }
        
        // 检查canvas尺寸是否有效
        if (canvas.width === 0 || canvas.height === 0) {
          throw new Error('二维码尺寸无效')
        }
        
        try {
          const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
          const hasContent = imageData.data.some((channel, index) => {
            // 检查alpha通道，如果有非透明像素则说明有内容
            return index % 4 === 3 && channel > 0
          })

          if (!hasContent) {
            throw new Error('二维码生成失败，canvas无内容')
          }
        } catch (imageError) {
          console.warn('Canvas内容验证失败，但继续执行:', imageError.message)
          // 如果获取图像数据失败，可能是跨域问题，但我们仍然认为二维码已生成
        }

        // 确认二维码生成完成后再显示结果
        this.qrCodeGenerated = true
        this.$message.success('二维码生成成功！')
      } catch (error) {
        console.error('生成二维码失败:', error)
        this.$message.error('生成二维码失败，请重试')
        // 如果生成失败，隐藏二维码显示区域
        this.qrCodeGenerated = false
      } finally {
        this.generating = false
      }
    },

    // 下载二维码
    downloadQrCode() {
      // 验证二维码是否已生成
      if (!this.qrCodeGenerated) {
        this.$message.warning('请先生成二维码')
        return
      }

      const canvas = this.$refs.qrCanvas
      if (!canvas) {
        this.$message.error('二维码画布不存在，请重新生成')
        return
      }

      // 验证canvas是否有内容
      const ctx = canvas.getContext('2d')
      if (!ctx) {
        this.$message.error('无法获取二维码画布，请重新生成')
        return
      }
      
      // 检查canvas尺寸是否有效
      if (canvas.width === 0 || canvas.height === 0) {
        this.$message.error('二维码尺寸无效，请重新生成')
        return
      }
      
      try {
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
        const hasContent = imageData.data.some((channel, index) => {
          return index % 4 === 3 && channel > 0
        })

        if (!hasContent) {
          this.$message.error('二维码内容为空，请重新生成')
          return
        }
      } catch (imageError) {
        console.warn('Canvas内容验证失败，但继续下载:', imageError.message)
        // 如果获取图像数据失败，可能是跨域问题，但我们仍然允许下载
      }

      try {
        const url = canvas.toDataURL('image/png')
        const link = document.createElement('a')
        const filename = `QR_${this.formData.operationType}_${this.formData.commodityId}_${Date.now()}.png`
        link.download = filename
        link.href = url
        link.click()
        this.$message.success('二维码下载成功！')
      } catch (error) {
        console.error('下载二维码失败:', error)
        this.$message.error('下载二维码失败，请重试')
      }
    },

    // 重置表单
    resetForm() {
      this.formData = {
        operationType: 'IN',
        commodityId: '',
        quantity: 1,
        remark: ''
      }
      this.qrCodeGenerated = false
      this.qrCodeData = ''
      this.selectedCommodity = null
    }
  }
}
</script>

<style scoped>
.qr-generator-container {
  padding: 24px;
  background: #f0f2f5;
  min-height: calc(100vh - 64px);
}

.qr-display-area {
  margin-top: 30px;
}

.qr-info-card {
  background: #fafafa;
  border: 1px solid #e8e8e8;
  border-radius: 4px;
  padding: 20px;
  margin-bottom: 20px;
}

.info-item {
  margin-bottom: 12px;
  display: flex;
  align-items: center;
}

.info-label {
  font-weight: 500;
  color: #666;
  margin-right: 8px;
  min-width: 80px;
}

.info-value {
  color: #333;
  font-weight: 500;
}

.qr-code-wrapper {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 30px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  margin-bottom: 20px;
}

.qr-canvas {
  border: 2px solid #e8e8e8;
  border-radius: 4px;
}

.qr-actions {
  display: flex;
  justify-content: center;
  padding-top: 10px;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .qr-generator-container {
    padding: 12px;
  }
  
  .qr-code-wrapper {
    padding: 15px;
  }
  
  .qr-canvas {
    max-width: 100%;
    height: auto;
  }
}
</style>
