<template>
  <div class="scanner-page">
    <div class="scanner-header">
      <h1>📱 仓库管理系统 - 扫码录入</h1>
      <p class="scanner-desc">使用摄像头扫描二维码，快速完成商品入库、出库操作</p>
    </div>
    
    <div class="scanner-container">
      <QrCodeScanner
        ref="scanner"
        title="扫码录入系统"
        operation-type="inbound"
        @scanned="onScanned"
        @confirm="onScannerConfirm"
      />
    </div>
    
    <div class="scanner-footer">
      <a-button @click="goToLogin" type="link">
        <a-icon type="user" />
        返回登录页面
      </a-button>
    </div>
  </div>
</template>

<script>
import QrCodeScanner from '@/components/QrCodeScanner.vue'

export default {
  name: 'Scanner',
  components: {
    QrCodeScanner
  },
  methods: {
    onScanned(barcode) {
      console.log('📱 扫描到条码:', barcode)
    },
    
    onScannerConfirm(operationData) {
      console.log('📦 扫码操作确认:', operationData)
      this.$message.success('扫码录入成功！')
    },
    
    goToLogin() {
      this.$router.push('/login')
    }
  }
}
</script>

<style scoped>
.scanner-page {
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  flex-direction: column;
  padding: 20px;
}

.scanner-header {
  text-align: center;
  color: white;
  margin-bottom: 30px;
}

.scanner-header h1 {
  font-size: 28px;
  margin-bottom: 10px;
  text-shadow: 0 2px 4px rgba(0,0,0,0.3);
}

.scanner-desc {
  font-size: 16px;
  opacity: 0.9;
  margin: 0;
}

.scanner-container {
  flex: 1;
  background: white;
  border-radius: 12px;
  box-shadow: 0 8px 32px rgba(0,0,0,0.1);
  padding: 20px;
  max-width: 800px;
  margin: 0 auto;
  width: 100%;
}

.scanner-footer {
  text-align: center;
  margin-top: 20px;
}

.scanner-footer .ant-btn-link {
  color: white;
  font-size: 14px;
}

/* 移动端适配 */
@media (max-width: 768px) {
  .scanner-page {
    padding: 10px;
  }
  
  .scanner-header h1 {
    font-size: 24px;
  }
  
  .scanner-desc {
    font-size: 14px;
  }
  
  .scanner-container {
    padding: 15px;
  }
}
</style>