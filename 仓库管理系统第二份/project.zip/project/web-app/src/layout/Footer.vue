<template>
  <a-layout-footer :style="{ textAlign: 'center', letterSpacing: '1px' }">
    物流快递仓库管理系统
  </a-layout-footer>
</template>

<script>
export default {
name: "Footer"
}
</script>

<style scoped>

</style>
