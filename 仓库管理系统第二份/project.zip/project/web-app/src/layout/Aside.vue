<template>
  <a-layout-sider
      :style="{ overflow: 'auto', height: '100vh', position: 'fixed', left: 0 }"
      width="220">
    <div class="logo">
      物流快递仓库管理系统
    </div>
    <a-menu 
      theme="dark" 
      mode="inline" 
      :selectedKeys="selectedKeys"
      :openKeys="openKeys"
      @click="handleMenuClick"
      @openChange="handleOpenChange"
    >
      <a-sub-menu v-for="(item, index) in menus" :key="item.title">
        <span slot="title">
          <a-icon :type="item.icon"/>
          <span>{{ item.title }}</span>
        </span>
        <a-menu-item v-for="menu in item.children" :key="menu.path">
          <a-icon v-if="menu.icon" :type="menu.icon"/>
          <span>{{ menu.title }}</span>
        </a-menu-item>
      </a-sub-menu>
    </a-menu>
  </a-layout-sider>
</template>

<script>
export default {
  data() {
    return {
      selectedKeys: ['/ecommerce/analysis'],
      openKeys: ['电子商务'], // 默认展开电子商务菜单
      menus: [
        {
          title: '电子商务',
          icon: 'shopping',
          children: [
            {title: '电子商务', path: '/ecommerce/main', icon: 'shop'},      // 新增
            {title: '分析页', path: '/ecommerce/analysis', icon: 'bar-chart'}, // 原来的分析页
          ]
        },
        {
          title: '基础管理',
          icon: 'home',
          children: [
            {title: '商品管理', path: '/basics/commodity', icon: 'appstore'},
            {title: '来往单位', path: '/company', icon: 'team'},
            {title: '员工管理', path: '/employee', icon: 'user'},
            {title: '仓库管理', path: '/warehouse', icon: 'shop'},
            // ========== 添加库存预警菜单 ==========
            {title: '库存预警', path: '/alerts', icon: 'warning'},
            // ========== 库存预警菜单结束 ==========
            // ========== 添加二维码生成菜单 ==========
            {title: '二维码生成', path: '/basics/qrcode', icon: 'qrcode'},
            // ========== 二维码生成菜单结束 ==========
          ]
        },
        {
          title: '销售管理',
          icon: 'pay-circle',
          children: [
            {title: '销售开票', path: '/sale/create', icon: 'file-add'},
            {title: '销售记录', path: '/sale/record', icon: 'file-text'},
          ]
        },
        {
          title: '配送管理',
          icon: 'car',
          children: [
            {title: '申请配送', path: '/delivery/create', icon: 'car'},
            {title: '配送列表', path: '/delivery/list', icon: 'ordered-list'},
          ]
        },
        {
          title: '运输管理',
          icon: 'rocket',
          children: [
            {title: '车辆资料', path: '/vehicle', icon: 'car'},
            {title: '驾驶员资料', path: '/driver', icon: 'idcard'},
          ]
        },
        {
          title: '图表分析',
          icon: 'line-chart',
          children: [
            {title: '入库分析', path: '/analyze/in', icon: 'arrow-down'},
            {title: '出库分析', path: '/analyze/out', icon: 'arrow-up'},
          ]
        },
        {
          title: '系统管理',
          icon: 'tool',
          children: [
            {title: '安全设置', path: '/security', icon: 'safety'},
            {title: '操作员管理', path: '/admin', icon: 'user'},
            {title: '权限列表', path: '/role', icon: 'key'},
          ]
        },
        {
          title: '日志管理',
          icon: 'file',
          children: [
            {title: '登录日志', path: '/loginlog', icon: 'login'},
            {title: '操作日志', path: '/systemlog', icon: 'history'},
          ]
        }
      ]
    }
  },

  methods: {
    handleMenuClick({ key }) {
      console.log('跳转到:', key)
      this.selectedKeys = [key]
      this.$router.push(key)
      // 触发事件，用于移动端关闭抽屉
      this.$emit('menuClick')
    },
    
    handleOpenChange(openKeys) {
      console.log('菜单展开状态变化:', openKeys)
      this.openKeys = openKeys
    }
  },

  mounted() {
    // 设置当前选中的菜单项
    this.selectedKeys = [this.$route.path]
    console.log('当前路由:', this.$route.path)
  },

  watch: {
    $route(to) {
      // 路由变化时更新选中的菜单项
      this.selectedKeys = [to.path]
      console.log('路由变化到:', to.path)
    }
  }
}
</script>

<style scoped>
#components-layout-demo-fixed-sider .logo {
  padding: 10px 15px;
  height: 50px;
  font-size: 15px;
  margin: 16px;
  color: #ffffff;
  letter-spacing: 2px;
}

.logo {
  padding: 10px 15px;
  height: 50px;
  font-size: 15px;
  margin: 16px;
  color: #ffffff;
  letter-spacing: 2px;
  background: #001529;
}

.ant-menu {
  letter-spacing: 1px;
}

.logo img {
  width: 32px;
  height: 32px;
  margin-right: 5px;
}

/* 移动端优化 */
@media (max-width: 767px) {
  .logo {
    font-size: 14px;
    text-align: center;
  }
}
</style>