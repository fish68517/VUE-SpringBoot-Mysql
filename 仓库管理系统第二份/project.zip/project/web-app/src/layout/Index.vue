<template>
  <a-layout id="components-layout-demo-fixed-sider">
    <!-- 桌面端：固定侧边栏 -->
    <Aside v-if="!isMobile" />
    
    <!-- 移动端：抽屉式侧边栏 -->
    <a-drawer
      v-else
      placement="left"
      :closable="false"
      :visible="mobileMenuVisible"
      @close="closeMobileMenu"
      :bodyStyle="{ padding: 0 }"
      width="220"
    >
      <Aside @menuClick="closeMobileMenu" />
    </a-drawer>
    
    <a-layout :style="layoutStyle">
      <Header @toggleMenu="toggleMobileMenu" :isMobile="isMobile" />
      <Main/>
      <Footer/>
    </a-layout>
  </a-layout>
</template>

<script>
import Aside from "@/layout/Aside";
import Header from "@/layout/Header";
import Main from "@/layout/Main";
import Footer from "@/layout/Footer";
import { isMobile } from '@/utils/responsive';

export default {
  components: {Aside, Header, Main, Footer},
  data() {
    return {
      isMobile: false,
      mobileMenuVisible: false
    }
  },
  computed: {
    layoutStyle() {
      return this.isMobile ? {} : { marginLeft: '220px' }
    }
  },
  methods: {
    toggleMobileMenu() {
      this.mobileMenuVisible = !this.mobileMenuVisible
    },
    closeMobileMenu() {
      this.mobileMenuVisible = false
    },
    checkDevice() {
      this.isMobile = isMobile()
    }
  },
  mounted() {
    this.checkDevice()
    window.addEventListener('resize', this.checkDevice)
    
    this.$message.success(
        '欢迎管理员 ' + this.$store.state.user.details.email, 6,
    );
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.checkDevice)
  }
}
</script>

<style scoped>
#components-layout-demo-fixed-sider .logo {
  padding: 10px 15px;
  height: 50px;
  font-size: 15px;
  margin: 16px;
  color: #ffffff;
  letter-spacing: 2px;
}

.logo img {
  width: 32px;
  height: 32px;
  margin-right: 5px;
}

.header {
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1)
}

</style>
