<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style>
@import './assets/styles/mobile.css';

/*顶部进度条样式*/
#nprogress .bar {
  background: #1890ff !important;
}

body {
  letter-spacing: 1px;
  background: #f0f2f5 !important;
  margin: 0;
  padding: 0;
}

/* 移动端全局优化 */
#app {
  width: 100%;
  overflow-x: hidden;
}

/* 移动端容器适配 */
@media (max-width: 767px) {
  body {
    font-size: 14px;
  }
}

</style>
