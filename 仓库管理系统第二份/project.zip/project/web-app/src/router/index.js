import Vue from 'vue'
import VueRouter from 'vue-router'
import store from '../store'
import routes from "@/router/routes"
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'

//顶部进度条样式
NProgress.configure({
    showSpinner: false,
    speed: 800,
});

Vue.use(VueRouter)

const router = new VueRouter({
    mode: 'history',
    base: process.env.BASE_URL,
    routes
})

//路由卫士
router.beforeEach((to, from, next) => {
    NProgress.start();
    // 允许访问的页面列表（包括扫码页面）
    const allowedPaths = ['/login', '/init', '/scanner'];
    // 如果目标路径在允许列表中，或者用户已登录，则允许访问
    if (allowedPaths.includes(to.path) || store.state.user.token) {
        next();
    } else {
        next("/login");
    }
})

router.afterEach(() => {
    NProgress.done()
})

export default router
