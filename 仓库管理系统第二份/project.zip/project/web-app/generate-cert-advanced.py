#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自签名SSL证书生成脚本 - 支持多网段访问
使用cryptography库生成支持多个域名和IP地址的SSL证书
"""

import os
import sys
from datetime import datetime, timedelta
from pathlib import Path

try:
    from cryptography import x509
    from cryptography.x509.oid import NameOID, ExtensionOID
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.backends import default_backend
except ImportError:
    print("❌ 缺少依赖库！")
    print("\n请先安装 cryptography 库:")
    print("  pip install cryptography")
    print("\n或者:")
    print("  conda install cryptography")
    sys.exit(1)


def generate_certificate():
    """生成支持多网段的自签名SSL证书"""
    
    # 创建证书目录
    cert_dir = Path(__file__).parent / "cert"
    cert_dir.mkdir(exist_ok=True)
    
    key_file = cert_dir / "localhost-key.pem"
    cert_file = cert_dir / "localhost-cert.pem"
    
    # 检查证书是否已存在
    if key_file.exists() and cert_file.exists():
        print("✓ 证书已存在，无需重新生成")
        print(f"  私钥: {key_file}")
        print(f"  证书: {cert_file}")
        return
    
    print("开始生成自签名SSL证书（支持多网段访问）...\n")
    
    # 生成私钥
    print("1. 生成RSA私钥 (2048位)...")
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )
    
    # 准备证书主体信息
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "CN"),
        x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME, "Beijing"),
        x509.NameAttribute(NameOID.LOCALITY_NAME, "Beijing"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Local Development"),
        x509.NameAttribute(NameOID.COMMON_NAME, "localhost"),
    ])
    
    # 生成证书
    print("2. 生成X.509证书...")
    
    # 支持的域名和IP地址
    san_list = [
        # DNS名称
        x509.DNSName("localhost"),
        x509.DNSName("*.localhost"),
        x509.DNSName("local.dev"),
        x509.DNSName("*.local.dev"),
        # IP地址
        x509.IPAddress(ipaddress.IPv4Address("127.0.0.1")),
        x509.IPAddress(ipaddress.IPv4Address("0.0.0.0")),
        x509.IPAddress(ipaddress.IPv6Address("::1")),
        # 添加本机局域网IP（如果需要）
        x509.IPAddress(ipaddress.IPv4Address("192.168.0.0")),
        x509.IPAddress(ipaddress.IPv4Address("192.168.1.0")),
        x509.IPAddress(ipaddress.IPv4Address("10.0.0.0")),
    ]
    
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(private_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(datetime.utcnow())
        .not_valid_after(datetime.utcnow() + timedelta(days=365))
        .add_extension(
            x509.SubjectAlternativeName(san_list),
            critical=False,
        )
        .add_extension(
            x509.BasicConstraints(ca=True, path_length=0),
            critical=True,
        )
        .add_extension(
            x509.KeyUsage(
                digital_signature=True,
                key_encipherment=True,
                key_cert_sign=True,
                crl_sign=True,
                content_commitment=False,
                data_encipherment=False,
                key_agreement=False,
                encipher_only=False,
                decipher_only=False,
            ),
            critical=True,
        )
        .add_extension(
            x509.ExtendedKeyUsage([
                x509.oid.ExtendedKeyUsageOID.SERVER_AUTH,
                x509.oid.ExtendedKeyUsageOID.CLIENT_AUTH,
            ]),
            critical=False,
        )
        .sign(private_key, hashes.SHA256(), default_backend())
    )
    
    # 保存私钥
    print("3. 保存私钥文件...")
    with open(key_file, "wb") as f:
        f.write(
            private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption()
            )
        )
    
    # 保存证书
    print("4. 保存证书文件...")
    with open(cert_file, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))
    
    print("\n✓ SSL证书生成成功！")
    print(f"  私钥文件: {key_file}")
    print(f"  证书文件: {cert_file}")
    print("\n证书特性:")
    print("  - 有效期: 365天")
    print("  - 支持域名: localhost, *.localhost, local.dev, *.local.dev")
    print("  - 支持IP: 127.0.0.1, ::1, 0.0.0.0 及常见局域网段")
    print("  - 密钥长度: RSA 2048位")
    print("  - 签名算法: SHA-256")
    print("\n提示:")
    print("  首次访问时浏览器会提示不安全，这是正常的。")
    print("  点击'高级'然后'继续访问'即可。")
    print("\n现在可以运行: npm run serve")


if __name__ == "__main__":
    try:
        import ipaddress
        generate_certificate()
    except Exception as e:
        print(f"\n❌ 证书生成失败: {e}")
        print("\n请确保:")
        print("  1. 已安装 cryptography 库: pip install cryptography")
        print("  2. Python版本 >= 3.6")
        sys.exit(1)
