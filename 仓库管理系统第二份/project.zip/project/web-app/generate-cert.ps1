# PowerShell脚本 - Windows下生成自签名SSL证书

$certDir = Join-Path $PSScriptRoot "cert"
$keyPath = Join-Path $certDir "localhost-key.pem"
$certPath = Join-Path $certDir "localhost-cert.pem"

# 创建证书目录
if (-not (Test-Path $certDir)) {
    New-Item -ItemType Directory -Path $certDir | Out-Null
    Write-Host "✓ 创建证书目录: cert/" -ForegroundColor Green
}

# 检查是否已存在证书
if ((Test-Path $keyPath) -and (Test-Path $certPath)) {
    Write-Host "✓ 证书已存在，无需重新生成" -ForegroundColor Green
    Write-Host "  私钥: $keyPath"
    Write-Host "  证书: $certPath"
    exit 0
}

Write-Host "开始生成自签名SSL证书..." -ForegroundColor Cyan
Write-Host ""

# 检查OpenSSL是否可用
$opensslAvailable = $false
try {
    $null = openssl version 2>&1
    $opensslAvailable = $true
} catch {
    Write-Host "✗ 系统未找到OpenSSL" -ForegroundColor Yellow
}

if ($opensslAvailable) {
    try {
        # 使用OpenSSL生成证书
        $command = "openssl req -x509 -newkey rsa:2048 -nodes -sha256 -subj '/CN=localhost' -keyout '$keyPath' -out '$certPath' -days 365"
        Invoke-Expression $command
        
        Write-Host ""
        Write-Host "✓ SSL证书生成成功！" -ForegroundColor Green
        Write-Host "  私钥文件: $keyPath"
        Write-Host "  证书文件: $certPath"
        Write-Host ""
        Write-Host "提示: 首次访问时浏览器会提示不安全，这是正常的。" -ForegroundColor Yellow
        Write-Host "      点击'高级'然后'继续访问'即可。" -ForegroundColor Yellow
        Write-Host ""
    } catch {
        Write-Host "✗ 证书生成失败: $_" -ForegroundColor Red
        exit 1
    }
} else {
    # 使用.NET生成证书（不需要OpenSSL）
    Write-Host "使用.NET生成自签名证书..." -ForegroundColor Cyan
    
    $cert = New-SelfSignedCertificate -DnsName "localhost" -CertStoreLocation "cert:\CurrentUser\My" -NotAfter (Get-Date).AddYears(1) -KeyExportPolicy Exportable
    
    # 导出证书
    $certPassword = ConvertTo-SecureString -String "temp" -Force -AsPlainText
    $pfxPath = Join-Path $certDir "localhost.pfx"
    Export-PfxCertificate -Cert $cert -FilePath $pfxPath -Password $certPassword | Out-Null
    
    # 从PFX提取PEM格式（需要OpenSSL或手动转换）
    Write-Host ""
    Write-Host "✓ 证书已生成到系统证书存储" -ForegroundColor Green
    Write-Host "  证书指纹: $($cert.Thumbprint)"
    Write-Host "  PFX文件: $pfxPath (密码: temp)"
    Write-Host ""
    Write-Host "注意: 需要将PFX转换为PEM格式，请执行以下命令:" -ForegroundColor Yellow
    Write-Host "  openssl pkcs12 -in '$pfxPath' -nocerts -nodes -out '$keyPath' -password pass:temp" -ForegroundColor Gray
    Write-Host "  openssl pkcs12 -in '$pfxPath' -clcerts -nokeys -out '$certPath' -password pass:temp" -ForegroundColor Gray
    Write-Host ""
    Write-Host "或者安装Git for Windows，使用Git Bash运行: node generate-cert.js" -ForegroundColor Yellow
    Write-Host ""
    
    # 清理证书存储
    Get-ChildItem "cert:\CurrentUser\My" | Where-Object { $_.Thumbprint -eq $cert.Thumbprint } | Remove-Item
}
